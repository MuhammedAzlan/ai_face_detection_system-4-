"""
View Detection Reports
========================
Usage:
    python view_report.py                    # Today's detections
    python view_report.py --date 2026-04-13  # Specific date
    python view_report.py --export           # Merge all logs into full_report.csv
    python view_report.py --summary          # One-line-per-day summary
    python view_report.py --person "John Doe" # Every logged sighting of one person
"""

import argparse
import os
import pandas as pd
from utils.logger import view_today_log, export_all_logs, LOGS_DIR


def view_date_log(date_str: str):
    log_file = os.path.join(LOGS_DIR, f"{date_str}.csv")
    if not os.path.exists(log_file):
        print(f"[INFO] No log found for {date_str}.")
        return
    df = pd.read_csv(log_file)
    print(f"\n{'-'*60}\n  Detection Log — {date_str}\n{'-'*60}")
    if df.empty:
        print("  No records.")
    else:
        print(df.to_string(index=False))
        print(f"\n  Total events: {len(df)}")
    print(f"{'-'*60}\n")


def summary_all_logs():
    if not os.path.exists(LOGS_DIR):
        print("[INFO] No logs found.")
        return
    files = sorted(f for f in os.listdir(LOGS_DIR) if f.endswith(".csv"))
    if not files:
        print("[INFO] No log files found.")
        return

    print(f"\n{'-'*60}\n  Detection Summary — All Days\n{'-'*60}")
    print(f"  {'Date':<14} {'Events':<8} {'Unique people'}")
    print(f"{'-'*60}")
    for file in files:
        date = file.replace(".csv", "")
        df = pd.read_csv(os.path.join(LOGS_DIR, file))
        unique = df["Name"].nunique() if not df.empty else 0
        print(f"  {date:<14} {len(df):<8} {unique}")
    print(f"{'-'*60}\n")


def view_person(name: str):
    if not os.path.exists(LOGS_DIR):
        print("[INFO] No logs found.")
        return
    files = sorted(f for f in os.listdir(LOGS_DIR) if f.endswith(".csv"))
    rows = []
    for file in files:
        df = pd.read_csv(os.path.join(LOGS_DIR, file))
        if not df.empty:
            rows.append(df[df["Name"].str.lower() == name.lower()])
    if not rows:
        print(f"[INFO] No sightings of '{name}' found.")
        return
    combined = pd.concat(rows, ignore_index=True)
    if combined.empty:
        print(f"[INFO] No sightings of '{name}' found.")
        return
    print(f"\n{'-'*60}\n  All sightings — {name}\n{'-'*60}")
    print(combined.to_string(index=False))
    print(f"\n  Total sightings: {len(combined)}")
    print(f"{'-'*60}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="View face detection reports.")
    parser.add_argument("--date", "-d", type=str, help="View log for a specific date (YYYY-MM-DD)")
    parser.add_argument("--export", "-e", action="store_true", help="Merge all logs into full_report.csv")
    parser.add_argument("--summary", "-s", action="store_true", help="Summary of all log dates")
    parser.add_argument("--person", "-p", type=str, help="Show every sighting of one person")
    args = parser.parse_args()

    if args.export:
        export_all_logs()
    elif args.summary:
        summary_all_logs()
    elif args.person:
        view_person(args.person)
    elif args.date:
        view_date_log(args.date)
    else:
        view_today_log()
