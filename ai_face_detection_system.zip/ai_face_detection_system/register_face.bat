@echo off
cd /d "%~dp0"
python register_face.py
pause
