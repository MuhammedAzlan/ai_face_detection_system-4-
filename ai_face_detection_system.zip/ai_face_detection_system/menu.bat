@echo off
cd /d "%~dp0"
title AI Face Detection System

:menu
cls
echo ================================================
echo    AI Face Detection System
echo ================================================
if exist detector.pid (
    echo    Status: RUNNING
) else (
    echo    Status: STOPPED
)
echo ================================================
echo   1. Start detection
echo   2. Stop detection
echo   3. Register a new face
echo   4. View today's detections
echo   5. Install / update dependencies
echo   6. Edit camera settings ^(config.json^)
echo   7. Exit
echo ================================================
set /p choice=Select an option (1-7): 

if "%choice%"=="1" (call start.bat) & goto menu
if "%choice%"=="2" (call stop.bat) & goto menu
if "%choice%"=="3" (call register_face.bat) & goto menu
if "%choice%"=="4" (call view_report.bat) & goto menu
if "%choice%"=="5" (call install.bat) & goto menu
if "%choice%"=="6" (notepad config.json) & goto menu
if "%choice%"=="7" exit /b 0

goto menu
