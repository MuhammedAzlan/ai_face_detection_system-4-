This folder contains daily detection CSV files, auto-created by detector.py.

Filename format: YYYY-MM-DD.csv
Columns: Name, Date, Time, Camera, Status

Every time a person is detected on camera, a new row is added with the
exact time they were seen (after a short per-person cooldown, set in
config.json, so one long visit doesn't create hundreds of rows).

View with: view_report.bat  (or: python view_report.py)
