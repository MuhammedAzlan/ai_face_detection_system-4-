@echo off
cd /d "%~dp0"

if not exist detector.pid (
    echo [INFO] No detector.pid found - detection doesn't look like it's running
    echo        ^(or was started outside of start.bat^).
    pause
    exit /b 0
)

set /p PID=<detector.pid
echo Stopping AI Face Detection System (PID %PID%)...

taskkill /PID %PID% /F >nul 2>&1
if %errorlevel%==0 (
    echo [OK] Stopped.
) else (
    echo [WARN] Process %PID% wasn't found - it may have already stopped.
)

del detector.pid >nul 2>&1
echo.
pause
