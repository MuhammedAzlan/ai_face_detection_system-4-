Place face images here so the system can recognize those people.

Naming convention (filename -> display name):
  firstname_lastname.jpg      ->  "Firstname Lastname"
  firstname_lastname_1.jpg    ->  Multiple photos of the same person (recommended)
  firstname_lastname_2.jpg

Supported formats: .jpg, .jpeg, .png

Easiest way to add someone:
  register_face.bat   (or: python register_face.py --name "John Doe" --file path\to\photo.jpg)

2-3 clear, well-lit, front-facing photos per person gives the best accuracy.
