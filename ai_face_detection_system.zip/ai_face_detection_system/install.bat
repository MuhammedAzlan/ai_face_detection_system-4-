@echo off
cd /d "%~dp0"
echo ============================================
echo   AI Face Detection System - Setup
echo ============================================
echo.
echo Installing Python dependencies...
echo (dlib may take a few minutes to build - this is normal)
echo.

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
if %errorlevel%==0 (
    echo [OK] Setup complete. Next steps:
    echo   1. Edit config.json with your camera's RTSP URL.
    echo   2. Run register_face.bat to add known faces.
    echo   3. Run start.bat to begin detection.
) else (
    echo [ERROR] Something failed during install.
    echo If dlib failed to build, download a prebuilt wheel from:
    echo   https://github.com/z-mahmud22/Dlib_Windows_Python3.x
    echo then run: pip install dlib-19.x.x-cpXX-win_amd64.whl
)
echo.
pause
