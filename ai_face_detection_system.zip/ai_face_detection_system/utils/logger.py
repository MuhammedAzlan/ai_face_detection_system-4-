"""
utils/logger.py
================
Logs every detection EVENT (not just "present today") to a daily CSV.
Each file is named YYYY-MM-DD.csv and stored in detection_logs/.

Columns: Name, Date, Time, Camera, Status
    Status is "Recognized" for a known face or "Unknown" for an
    unrecognized one (if log_unknown is enabled in config.json).
"""

import pandas as pd
import os
from datetime import datetime

LOGS_DIR = "detection_logs"


def get_today_log() -> str:
    """Return the filepath for today's detection log CSV."""
    today = datetime.now().strftime("%Y-%m-%d")
    return os.path.join(LOGS_DIR, f"{today}.csv")


def log_detection(name: str, camera_name: str, status: str = "Recognized") -> None:
    """
    Append one detection event to today's CSV.

    Args:
        name        : Person's display name, or "Unknown".
        camera_name : Which camera/channel saw them (useful with multiple cams).
        status      : "Recognized" or "Unknown".
    """
    os.makedirs(LOGS_DIR, exist_ok=True)
    log_file = get_today_log()

    now = datetime.now()
    row = {
        "Name": name,
        "Date": now.strftime("%Y-%m-%d"),
        "Time": now.strftime("%H:%M:%S"),
        "Camera": camera_name,
        "Status": status,
    }

    if not os.path.exists(log_file):
        pd.DataFrame(columns=list(row.keys())).to_csv(log_file, index=False)

    df = pd.read_csv(log_file)
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    df.to_csv(log_file, index=False)

    print(f"[DETECTED] {name}  ({status})  |  {row['Time']}  |  {camera_name}")


def view_today_log() -> None:
    """Print today's detection log to console."""
    log_file = get_today_log()

    if not os.path.exists(log_file):
        print("[INFO] No detections logged today yet.")
        return

    df = pd.read_csv(log_file)

    if df.empty:
        print("[INFO] No detections logged today yet.")
    else:
        print(f"\n{'-'*60}")
        print(f"  Detection Log — {datetime.now().strftime('%Y-%m-%d')}")
        print(f"{'-'*60}")
        print(df.to_string(index=False))
        print(f"{'-'*60}")
        print(f"  Total events: {len(df)}")
        print(f"{'-'*60}\n")


def export_all_logs(output_path: str = "full_report.csv") -> None:
    """Merge every daily CSV in detection_logs/ into one combined file."""
    if not os.path.exists(LOGS_DIR):
        print("[WARN] No logs directory found.")
        return

    files = sorted(
        os.path.join(LOGS_DIR, f) for f in os.listdir(LOGS_DIR) if f.endswith(".csv")
    )

    if not files:
        print("[WARN] No log files found.")
        return

    all_dfs = [pd.read_csv(f) for f in files if os.path.getsize(f) > 0]
    merged = pd.concat(all_dfs, ignore_index=True)
    merged.to_csv(output_path, index=False)
    print(f"[OK] Full report exported: {output_path} ({len(merged)} events)")
