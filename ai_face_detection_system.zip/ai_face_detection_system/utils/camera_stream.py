"""
utils/camera_stream.py
=======================
Threaded reader for a local webcam, RTSP IP camera, or NVR channel.

Two problems this solves that the original webcam-only code didn't have to:

1. RTSP streams buffer internally. If you just call cam.read() in your main
   loop, face detection (which is slow) falls behind and you end up watching
   video from several seconds ago. Reading in a background thread and always
   grabbing the newest frame avoids that lag.

2. IP cameras/NVRs drop connections (network blips, camera reboot, etc).
   This class detects a dead stream and automatically reconnects instead of
   crashing the whole program.
"""

import cv2
import threading
import time


class CameraStream:
    def __init__(self, source, reconnect_delay: float = 5, name: str = "Camera"):
        # source can be an RTSP/HTTP URL (str) or a webcam index (int, e.g. 0)
        self.source = source
        self.reconnect_delay = reconnect_delay
        self.name = name

        self.cap = None
        self.frame = None
        self.lock = threading.Lock()
        self.running = False
        self.connected = False
        self.thread = None

    def _connect(self) -> bool:
        if self.cap is not None:
            self.cap.release()
        self.cap = cv2.VideoCapture(self.source)
        try:
            # Keep the OS/driver buffer as small as possible so we always
            # get a recent frame rather than a queued-up old one.
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        self.connected = self.cap.isOpened()
        if self.connected:
            print(f"[INFO] {self.name}: connected.")
        return self.connected

    def start(self):
        self.running = True
        self._connect()
        self.thread = threading.Thread(target=self._update, daemon=True)
        self.thread.start()
        return self

    def _update(self):
        while self.running:
            if not self.connected:
                print(f"[WARN] {self.name}: not connected. Retrying in {self.reconnect_delay}s...")
                time.sleep(self.reconnect_delay)
                self._connect()
                continue

            ret, frame = self.cap.read()
            if not ret or frame is None:
                print(f"[WARN] {self.name}: lost the stream. Reconnecting...")
                self.connected = False
                continue

            with self.lock:
                self.frame = frame

    def read(self):
        """Return the most recent frame (or None if nothing received yet)."""
        with self.lock:
            return None if self.frame is None else self.frame.copy()

    def is_connected(self) -> bool:
        return self.connected

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=2)
        if self.cap is not None:
            self.cap.release()
