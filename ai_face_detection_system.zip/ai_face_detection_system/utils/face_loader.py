"""
utils/face_loader.py
=====================
Loads and encodes known faces from a directory of images.
Supports .jpg, .jpeg, and .png files.

Filename -> display name convention:
    john_doe.jpg     -> "John Doe"
    john_doe_1.jpg    -> "John Doe"  (multiple reference photos, same person)
    john_doe_2.jpg
"""

import face_recognition
import os


def load_known_faces(folder: str = "known_faces"):
    """
    Scan a folder for face images and return their encodings.

    Args:
        folder : Path to the directory containing face images.

    Returns:
        tuple: (list of encodings, list of names)
    """
    encodings = []
    names = []

    if not os.path.exists(folder):
        print(f"[WARN] Folder '{folder}' not found. Creating it...")
        os.makedirs(folder, exist_ok=True)
        return encodings, names

    supported = (".jpg", ".jpeg", ".png")
    files = [f for f in os.listdir(folder) if f.lower().endswith(supported)]

    if not files:
        print(f"[WARN] No images found in '{folder}'.")
        return encodings, names

    print(f"[INFO] Loading known faces from '{folder}'...")

    for filename in sorted(files):
        path = os.path.join(folder, filename)
        try:
            img = face_recognition.load_image_file(path)
            enc = face_recognition.face_encodings(img)

            if not enc:
                print(f"  [SKIP] No face detected in: {filename}")
                continue

            if len(enc) > 1:
                print(f"  [WARN] Multiple faces in {filename} — using first face only.")

            base = os.path.splitext(filename)[0]
            base = base.rstrip("_0123456789").rstrip("_")
            display_name = base.replace("_", " ").title()

            encodings.append(enc[0])
            names.append(display_name)
            print(f"  [OK] Loaded: {display_name} ({filename})")

        except Exception as e:
            print(f"  [ERROR] Could not process {filename}: {e}")

    print(f"[INFO] Total encodings loaded: {len(encodings)}\n")
    return encodings, names
