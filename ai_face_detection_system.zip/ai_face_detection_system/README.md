# AI Face Detection System — NVR / IP Camera Edition

Watches a live feed from your NVR/IP camera and, whenever a person moves in
front of it, detects their face and logs **who** and **what time** they
were seen. Not attendance — a running detection log, e.g.:

```
Name        Date        Time      Camera            Status
Shariq      2026-09-19  09:02:15  Front Gate Camera  Recognized
Azlan       2026-09-19  09:05:43  Front Gate Camera  Recognized
Unknown     2026-09-19  09:11:02  Front Gate Camera  Unknown
Shariq      2026-09-19  13:40:07  Front Gate Camera  Recognized   <- back again later
```

## What changed from the original version

- **Camera source**: was webcam-only. Now reads an RTSP stream from your
  NVR/IP camera, with auto-reconnect if the stream drops.
- **Logging**: was "mark present once per day". Now logs **every**
  appearance, with a configurable cooldown per person (default 60s) so a
  single visit doesn't spam the log, but a second visit later still gets
  logged.
- **Settings**: was hardcoded at the top of the .py files. Now all in
  `config.json` — no code editing.
- **Start/stop**: new `start.bat` / `stop.bat` run detection in the
  background and stop it cleanly. `menu.bat` ties everything together in
  one simple screen.
- Removed a hardcoded IP-camera username/password that was sitting in the
  old `app.py`'s HTML — that should never ship in code. Camera credentials
  now live only in your local `config.json`.

## Folder structure

```
ai_face_detection_system/
├── config.json          <- camera URL, sensitivity, cooldown - EDIT THIS
├── detector.py           <- main program (run this to start watching)
├── register_face.py      <- add a known person
├── view_report.py        <- view / export detection logs
├── requirements.txt
├── menu.bat               <- easiest way to use everything
├── install.bat            <- one-time setup
├── start.bat / stop.bat   <- run detection in the background
├── register_face.bat / view_report.bat
├── utils/
│   ├── camera_stream.py   <- threaded RTSP reader with auto-reconnect
│   ├── face_loader.py
│   └── logger.py
├── known_faces/           <- put reference photos here
└── detection_logs/        <- daily CSV logs (auto-created)
```

## Setup (Windows)

1. **Install Python 3.10+** if you don't have it (check "Add to PATH" during install).
2. Double-click **`install.bat`** (or `menu.bat` → option 5).
   - If `dlib` fails to build: download a prebuilt wheel from
     https://github.com/z-mahmud22/Dlib_Windows_Python3.x and run
     `pip install dlib-19.x.x-cpXX-win_amd64.whl`, then re-run install.bat.
3. **Edit `config.json`** with your NVR/camera's RTSP URL. Get this from
   your NVR's network/RTSP settings page. Common formats:
   - Hikvision: `rtsp://user:pass@192.168.1.64:554/Streaming/Channels/101`
   - Dahua: `rtsp://user:pass@192.168.1.64:554/cam/realmonitor?channel=1&subtype=0`
   - Generic ONVIF: check your NVR's manual for its RTSP path.
   You can test the URL first in VLC (Media → Open Network Stream) before
   putting it in config.json.
4. Register known people — double-click **`register_face.bat`**, or:
   ```
   python register_face.py --name "John Doe" --file path\to\photo.jpg
   ```
   (a clear, front-facing photo works fine — no need for a live webcam.)

## Running it

Easiest: double-click **`menu.bat`** and pick an option.

Or directly:
- **`start.bat`** — starts detection in the background, saves its process
  ID to `detector.pid` so it can be stopped cleanly later.
- **`stop.bat`** — stops it.
- **`python detector.py`** — run it directly in a console window (shows
  the live preview, Q to quit, R to reload known faces).

## Viewing detections

- `view_report.bat`, or `python view_report.py` — today's detections
- `python view_report.py --date 2026-09-19` — a specific day
- `python view_report.py --person "John Doe"` — every sighting of one person
- `python view_report.py --summary` — one line per day
- `python view_report.py --export` — merges every day into `full_report.csv`

## Key settings (`config.json`)

| Setting | What it does |
|---|---|
| `camera.source` | RTSP URL of your NVR channel (or `0` for a local webcam) |
| `detection.tolerance` | Match strictness. Lower = stricter (0.4–0.6 typical) |
| `detection.cooldown_seconds` | Minimum gap before the same person is logged again |
| `detection.process_every_n_frames` | Skip frames to reduce CPU load (RTSP + face recognition is heavy) |
| `detection.log_unknown` | Also log unrecognized faces as "Unknown" |
| `display.show_window` | Set `false` for headless/background running (no preview window) |

## A couple of practical notes

- **Performance**: `face_recognition` (dlib) is CPU-heavy. On a modest PC,
  expect maybe 3–8 frames/sec of actual detection — fine for a doorway/gate
  camera, not fine for a busy area with fast-moving crowds. Raising
  `process_every_n_frames` or lowering `scale_factor` trades accuracy for
  speed.
- **Multiple cameras**: run a second copy of this folder with a different
  `config.json` (different `camera.source` and `camera.name`), or extend
  `detector.py` to loop over several `CameraStream` instances if you want
  one process watching several channels at once.
- **Privacy/compliance**: continuous face detection on a camera feed is
  regulated in a lot of places (workplace monitoring notices, local
  privacy law, etc.). Worth checking what applies before deploying this
  somewhere people don't expect to be identified.

## License

MIT — free to use and modify for personal or commercial projects.
