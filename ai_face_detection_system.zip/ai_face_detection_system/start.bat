@echo off
cd /d "%~dp0"

if exist detector.pid (
    echo [WARN] detector.pid already exists - the detector may already be running.
    echo        Run stop.bat first. If it's not actually running, delete detector.pid
    echo        and try again.
    pause
    exit /b 1
)

echo Starting AI Face Detection System...
powershell -NoProfile -Command ^
  "$p = Start-Process -FilePath 'python' -ArgumentList 'detector.py' -WindowStyle Normal -PassThru; $p.Id | Out-File -Encoding ascii 'detector.pid'"

if exist detector.pid (
    set /p PID=<detector.pid
    echo [OK] Started. PID: %PID%
    echo      A preview window should appear shortly ^(unless show_window is false in config.json^).
    echo      To stop it later, run stop.bat.
) else (
    echo [ERROR] Failed to start. Check that Python is installed and on PATH.
)
echo.
pause
