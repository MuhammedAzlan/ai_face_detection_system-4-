"""
Face Registration Script
=========================
Adds a person to known_faces/ so the detector can recognize them.

Two ways to register:
    1. From an existing photo file (fastest, works on a headless server
       with no webcam attached to it — e.g. an ID photo, phone photo):
           python register_face.py --name "John Doe" --file photo.jpg

    2. Live capture from a local webcam attached to THIS computer
       (not the NVR — the NVR feed is only used by detector.py):
           python register_face.py --name "John Doe" --samples 3

    3. Interactive (asks what you want):
           python register_face.py

    List everyone currently registered:
           python register_face.py --list
"""

import cv2
import os
import shutil
import argparse
import face_recognition

KNOWN_FACES_DIR = "known_faces"


def _safe_filename(name: str, suffix: str = "") -> str:
    safe_name = name.strip().replace(" ", "_").lower()
    return f"{safe_name}{suffix}.jpg"


def register_from_file(name: str, file_path: str) -> bool:
    """Copy an existing photo into known_faces/, after checking it has a face."""
    if not os.path.exists(file_path):
        print(f"[ERROR] File not found: {file_path}")
        return False

    try:
        img = face_recognition.load_image_file(file_path)
        encs = face_recognition.face_encodings(img)
    except Exception as e:
        print(f"[ERROR] Could not read image: {e}")
        return False

    if not encs:
        print("[ERROR] No face detected in that photo. Use a clearer, front-facing photo.")
        return False
    if len(encs) > 1:
        print("[WARN] Multiple faces detected — make sure this photo shows only one person.")

    os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
    dest = os.path.join(KNOWN_FACES_DIR, _safe_filename(name))
    shutil.copyfile(file_path, dest)
    print(f"[OK] Registered '{name}' from {file_path} -> {dest}")
    return True


def register_from_webcam(name: str, num_samples: int = 1) -> bool:
    """Capture one or more photos via a webcam attached to this computer."""
    os.makedirs(KNOWN_FACES_DIR, exist_ok=True)

    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        print("[ERROR] Cannot open local webcam. If this machine has no webcam, "
              "use --file instead to register from an existing photo.")
        return False

    print(f"\n[INFO] Registering: {name}")
    print("[INFO] Position your face in the frame.")
    print("[INFO] Press SPACE to capture  |  Q to cancel\n")

    captured = 0
    while captured < num_samples:
        ret, frame = cam.read()
        if not ret:
            continue

        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        cx, cy = w // 2, h // 2
        cv2.ellipse(frame, (cx, cy), (100, 130), 0, 0, 360, (0, 255, 0), 2)
        cv2.putText(frame, f"Capturing {captured + 1}/{num_samples} - SPACE to snap",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        cv2.putText(frame, f"Name: {name}",
                    (10, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        cv2.imshow("Register Face", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord(' '):
            suffix = f"_{captured + 1}" if num_samples > 1 else ""
            path = os.path.join(KNOWN_FACES_DIR, _safe_filename(name, suffix))
            cv2.imwrite(path, frame)
            captured += 1
            print(f"[OK] Saved ({captured}/{num_samples}): {path}")

            white = frame.copy()
            white[:] = (255, 255, 255)
            cv2.imshow("Register Face", white)
            cv2.waitKey(150)
        elif key == ord('q'):
            print("[INFO] Registration cancelled.")
            break

    cam.release()
    cv2.destroyAllWindows()

    if captured == num_samples:
        print(f"\n[OK] Registration complete for '{name}' ({captured} image(s)).")
        return True
    print(f"\n[WARN] Only {captured}/{num_samples} images captured.")
    return captured > 0


def list_registered():
    if not os.path.exists(KNOWN_FACES_DIR):
        print("[INFO] No faces registered yet.")
        return

    files = [f for f in os.listdir(KNOWN_FACES_DIR)
             if f.lower().endswith((".jpg", ".jpeg", ".png"))]

    if not files:
        print("[INFO] No faces registered yet.")
    else:
        print(f"\n[INFO] Registered faces ({len(files)}):")
        for f in sorted(files):
            display = os.path.splitext(f)[0].rstrip("_0123456789").rstrip("_")
            print(f"  - {display.replace('_', ' ').title()}  ({f})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Register a face for the detection system.")
    parser.add_argument("--name", "-n", type=str, help="Full name of the person")
    parser.add_argument("--file", "-f", type=str, help="Path to an existing photo of them")
    parser.add_argument("--samples", "-s", type=int, default=1,
                         help="Number of webcam photos to capture (default: 1)")
    parser.add_argument("--list", "-l", action="store_true", help="List all registered faces and exit")
    args = parser.parse_args()

    if args.list:
        list_registered()
    else:
        name = args.name or input("Enter person's full name: ").strip()
        if not name:
            print("[ERROR] Name cannot be empty.")
        elif args.file:
            register_from_file(name, args.file)
        else:
            register_from_webcam(name, num_samples=args.samples)
