"""
app.py
======
Web dashboard for the AI Face Detection System.

Shows the live camera feed, who's currently in frame vs. who has left
(with arrival/departure times and a face thumbnail), today's detection
log, and lets you edit camera settings or register a new face - all
from the browser instead of editing files.

Run:
    python app.py
Then open:
    http://localhost:5000
"""

import os
import time
import base64
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
from flask import Flask, Response, jsonify, request, render_template_string

from engine import DetectionEngine, load_config, save_config
from utils.logger import LOGS_DIR
import register_face

app = Flask(__name__)
engine = DetectionEngine()


# ───────────────────────────── video stream ─────────────────────────────

def _placeholder_jpeg(message: str) -> bytes:
    frame = np.zeros((360, 640, 3), dtype=np.uint8)
    cv2.putText(frame, message, (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (60, 60, 220), 2)
    ok, buf = cv2.imencode(".jpg", frame)
    return buf.tobytes()


@app.route("/video_feed")
def video_feed():
    def gen():
        boundary = b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
        while True:
            if not engine.is_running():
                data = _placeholder_jpeg("Detection is stopped - press Start")
            else:
                jpeg = engine.get_jpeg()
                data = jpeg if jpeg else _placeholder_jpeg("Connecting to camera...")
            yield boundary + data + b"\r\n"
            time.sleep(0.05)

    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")


# ───────────────────────────── JSON API ─────────────────────────────

@app.route("/api/presence")
def api_presence():
    snap = engine.get_presence_snapshot()
    now = time.time()
    people = []
    for name, e in sorted(snap.items(), key=lambda kv: -kv[1]["last_seen"]):
        left_at = e["left_at"]
        people.append({
            "name": e["name"],
            "kind": e["kind"],
            "status": e["status"],
            "first_seen": datetime.fromtimestamp(e["first_seen"]).strftime("%H:%M:%S"),
            "last_seen": datetime.fromtimestamp(e["last_seen"]).strftime("%H:%M:%S"),
            "left_at": datetime.fromtimestamp(left_at).strftime("%H:%M:%S") if left_at else None,
            "duration_seconds": int((left_at or now) - e["first_seen"]),
            "thumbnail": e["thumbnail"],
        })
    return jsonify({
        "running": engine.is_running(),
        "connected": bool(engine.connected),
        "present_count": sum(1 for p in people if p["status"] == "IN"),
        "known_count": len(engine.known_names),
        "people": people,
    })


@app.route("/api/log")
def api_log():
    date = request.args.get("date") or datetime.now().strftime("%Y-%m-%d")
    log_file = os.path.join(LOGS_DIR, f"{date}.csv")
    records = []
    if os.path.exists(log_file):
        df = pd.read_csv(log_file)
        records = df.to_dict(orient="records")
    return jsonify({"date": date, "count": len(records), "records": records})


@app.route("/api/control/start", methods=["POST"])
def api_control_start():
    engine.start()
    return jsonify({"ok": True, "running": engine.is_running()})


@app.route("/api/control/stop", methods=["POST"])
def api_control_stop():
    engine.stop()
    return jsonify({"ok": True, "running": engine.is_running()})


@app.route("/api/reload_faces", methods=["POST"])
def api_reload_faces():
    count = engine.reload_faces()
    return jsonify({"ok": True, "count": count, "names": engine.known_names})


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "GET":
        return jsonify(load_config())

    data = request.get_json(force=True, silent=True) or {}
    cfg = load_config()
    for section in ("camera", "detection", "paths", "display"):
        if section in data and isinstance(data[section], dict):
            cfg.setdefault(section, {}).update(data[section])
    save_config(cfg)
    engine.reload_config()
    return jsonify({"ok": True, "config": cfg})


@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    image_b64 = data.get("image") or ""

    if not name:
        return jsonify({"ok": False, "error": "Name is required."})
    if not image_b64:
        return jsonify({"ok": False, "error": "Photo is required."})

    try:
        if "," in image_b64:
            image_b64 = image_b64.split(",", 1)[1]
        img_bytes = base64.b64decode(image_b64)
        arr = np.frombuffer(img_bytes, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return jsonify({"ok": False, "error": "Could not read that image."})

        os.makedirs("known_faces", exist_ok=True)
        tmp_path = os.path.join("known_faces", "_upload_tmp.jpg")
        cv2.imwrite(tmp_path, img)

        ok = register_face.register_from_file(name, tmp_path)
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

        if not ok:
            return jsonify({"ok": False, "error": "No face detected in that photo. Use a clearer, front-facing photo."})

        count = engine.reload_faces()
        return jsonify({"ok": True, "message": f"'{name}' registered.", "known_count": count})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


# ───────────────────────────── page ─────────────────────────────

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AI Face Detection Dashboard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#0f172a;color:#e2e8f0}
header{background:linear-gradient(135deg,#1e3a8a,#3b82f6);padding:14px 28px;
       display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px}
header h1{font-size:1.3rem;font-weight:700}
.header-right{display:flex;align-items:center;gap:14px;font-size:.85rem;color:#bfdbfe}
.container{max-width:1400px;margin:0 auto;padding:20px 16px}
.stats{display:flex;gap:14px;margin-bottom:20px;flex-wrap:wrap}
.stat{flex:1;min-width:140px;background:#1e293b;border-radius:12px;padding:14px 18px;border-left:4px solid #3b82f6}
.stat.green{border-color:#22c55e}
.stat.yellow{border-color:#eab308}
.stat.red{border-color:#ef4444}
.stat-label{font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px}
.stat-value{font-size:1.6rem;font-weight:700;color:#f1f5f9}
.grid{display:grid;grid-template-columns:1.3fr 1fr;gap:18px}
@media(max-width:1000px){.grid{grid-template-columns:1fr}}
.card{background:#1e293b;border-radius:14px;border:1px solid #334155;overflow:hidden;margin-bottom:16px}
.card-header{padding:12px 16px;font-weight:600;font-size:.92rem;border-bottom:1px solid #334155;
             background:#162032;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.card-body{padding:14px 16px}
.cam-img{width:100%;display:block;min-height:240px;background:#0f172a}
.btn{padding:8px 14px;border:none;border-radius:8px;font-size:.8rem;font-weight:600;cursor:pointer;
     transition:all .15s;display:inline-flex;align-items:center;gap:6px}
.btn:hover{opacity:.85}
.btn-blue{background:#3b82f6;color:#fff}
.btn-green{background:#22c55e;color:#fff}
.btn-red{background:#ef4444;color:#fff}
.btn-gray{background:#334155;color:#e2e8f0}
.btn-row{display:flex;gap:8px;flex-wrap:wrap}
.badge{font-size:.68rem;padding:2px 9px;border-radius:20px;font-weight:700}
.badge.here{background:#14532d;color:#4ade80}
.badge.left{background:#3f3f1a;color:#facc15}
.badge.unknown{background:#4c1d1d;color:#f87171}
.people-list{display:flex;flex-direction:column;gap:8px;max-height:520px;overflow-y:auto}
.person{display:flex;gap:10px;align-items:center;background:#0f172a;border:1px solid #253045;
        border-radius:10px;padding:8px 10px}
.person img{width:48px;height:48px;border-radius:8px;object-fit:cover;background:#334155}
.person-info{flex:1;min-width:0}
.person-name{font-weight:600;font-size:.88rem;display:flex;align-items:center;gap:8px}
.person-times{font-size:.72rem;color:#94a3b8;margin-top:2px}
.no-rec{color:#475569;text-align:center;padding:24px;font-size:.85rem}
table{width:100%;border-collapse:collapse;font-size:.8rem}
th{text-align:left;padding:7px 8px;color:#64748b;font-size:.66rem;text-transform:uppercase;
   letter-spacing:.5px;border-bottom:1px solid #334155}
td{padding:8px;border-bottom:1px solid #1a2744}
.log-scroll{max-height:280px;overflow-y:auto}
.status-dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.status-dot.on{background:#22c55e}
.status-dot.off{background:#ef4444}
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:100;
          align-items:center;justify-content:center}
.modal-bg.show{display:flex}
.modal{background:#1e293b;border-radius:14px;border:1px solid #334155;width:460px;max-width:94vw;
       max-height:90vh;overflow-y:auto}
.modal-header{padding:14px 18px;background:#162032;border-bottom:1px solid #334155;
              display:flex;align-items:center;justify-content:space-between}
.modal-body{padding:18px}
.modal-close{background:none;border:none;color:#94a3b8;font-size:1.3rem;cursor:pointer}
.form-group{margin-bottom:12px}
.form-group label{display:block;font-size:.78rem;color:#94a3b8;margin-bottom:5px;font-weight:500}
.form-group input,.form-group select{width:100%;padding:8px 10px;background:#0f172a;
     border:1px solid #334155;border-radius:8px;color:#e2e8f0;font-size:.85rem;outline:none}
.form-group input:focus{border-color:#3b82f6}
.form-row{display:flex;gap:10px}
.form-row .form-group{flex:1}
.upload-area{border:2px dashed #334155;border-radius:10px;padding:20px;text-align:center;
             cursor:pointer;margin-bottom:10px}
.upload-area:hover{border-color:#3b82f6;background:#162032}
#previewImg{width:100%;border-radius:8px;display:none;margin-bottom:10px;max-height:200px;object-fit:cover}
.msg{font-size:.8rem;min-height:18px;margin-top:6px;font-weight:500}
.msg.success{color:#4ade80}
.msg.error{color:#f87171}
.tabbtn{padding:8px 12px;font-size:.8rem;border-radius:8px;border:1px solid #334155;
        background:#0f172a;color:#94a3b8;cursor:pointer}
.tabbtn.active{background:#3b82f6;color:#fff;border-color:#3b82f6}
</style>
</head>
<body>

<header>
  <h1>AI Face Detection Dashboard</h1>
  <div class="header-right">
    <span><span class="status-dot" id="connDot"></span> <span id="connText">-</span></span>
    <span id="clock"></span>
  </div>
</header>

<div class="container">
  <div class="stats">
    <div class="stat green"><div class="stat-label">Here Now</div><div class="stat-value" id="presentCount">-</div></div>
    <div class="stat"><div class="stat-label">Registered Faces</div><div class="stat-value" id="knownCount">-</div></div>
    <div class="stat yellow"><div class="stat-label">Detections Today</div><div class="stat-value" id="todayCount">-</div></div>
    <div class="stat red" id="statusStat"><div class="stat-label">Detection</div>
      <div class="stat-value" style="font-size:1.1rem;padding-top:5px" id="runStatus">-</div></div>
  </div>

  <div class="grid">
    <div>
      <div class="card">
        <div class="card-header">
          Live Camera Feed
          <div class="btn-row">
            <button class="btn btn-green" onclick="controlDetection('start')">Start</button>
            <button class="btn btn-red" onclick="controlDetection('stop')">Stop</button>
          </div>
        </div>
        <img id="camFeed" class="cam-img" src="/video_feed" alt="Camera feed"/>
      </div>

      <div class="card">
        <div class="card-header">
          Today's Detection Log
          <div class="btn-row">
            <input type="date" id="logDate" style="padding:5px 8px;border-radius:6px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;font-size:.78rem"/>
            <button class="btn btn-gray" onclick="loadLog()">Refresh</button>
          </div>
        </div>
        <div class="card-body log-scroll">
          <div id="logContainer"><p class="no-rec">Loading...</p></div>
        </div>
      </div>
    </div>

    <div>
      <div class="card">
        <div class="card-header">
          Controls
        </div>
        <div class="card-body">
          <div class="btn-row" style="margin-bottom:0">
            <button class="btn btn-blue" onclick="reloadFaces()">Reload Faces</button>
            <button class="btn btn-blue" onclick="openRegister()">Register Face</button>
            <button class="btn btn-gray" onclick="openSettings()">Settings</button>
          </div>
          <div class="msg" id="ctrlMsg"></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">Who's on Camera</div>
        <div class="card-body">
          <div class="people-list" id="peopleList"><p class="no-rec">No one detected yet.</p></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Settings Modal -->
<div class="modal-bg" id="settingsModal">
  <div class="modal">
    <div class="modal-header"><h3>Camera & Detection Settings</h3>
      <button class="modal-close" onclick="closeModal('settingsModal')">&times;</button></div>
    <div class="modal-body">
      <div class="form-group"><label>Camera Name</label><input id="s_camera_name"/></div>
      <div class="form-group"><label>RTSP / Camera Source URL</label><input id="s_camera_source" placeholder="rtsp://user:pass@ip:554/..."/></div>
      <div class="form-row">
        <div class="form-group"><label>Tolerance (lower=stricter)</label><input id="s_tolerance" type="number" step="0.05"/></div>
        <div class="form-group"><label>Cooldown (sec, log repeat)</label><input id="s_cooldown" type="number"/></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Presence timeout (sec)</label><input id="s_presence" type="number"/></div>
        <div class="form-group"><label>Process every N frames</label><input id="s_everyn" type="number"/></div>
      </div>
      <div class="form-group">
        <label>Log unrecognized faces as "Unknown"</label>
        <select id="s_logunknown"><option value="true">Yes</option><option value="false">No</option></select>
      </div>
      <div class="msg" id="settingsMsg"></div>
      <div class="btn-row" style="margin-top:14px">
        <button class="btn btn-green" onclick="saveSettings()" style="flex:1">Save & Apply</button>
        <button class="btn btn-gray" onclick="closeModal('settingsModal')" style="flex:1">Cancel</button>
      </div>
      <p style="font-size:.72rem;color:#64748b;margin-top:10px">
        Changing the camera source takes effect the next time you press Start (stop first if it's already running).
      </p>
    </div>
  </div>
</div>

<!-- Register Modal -->
<div class="modal-bg" id="registerModal">
  <div class="modal">
    <div class="modal-header"><h3>Register a New Face</h3>
      <button class="modal-close" onclick="closeModal('registerModal')">&times;</button></div>
    <div class="modal-body">
      <div class="form-group"><label>Full Name</label><input id="r_name" placeholder="e.g. John Doe"/></div>
      <div class="upload-area" onclick="document.getElementById('r_file').click()">
        <div style="font-size:2rem">+</div>
        <p style="color:#64748b;font-size:.8rem;margin-top:6px">Click to select a clear, front-facing photo</p>
      </div>
      <input type="file" id="r_file" accept="image/*" style="display:none" onchange="previewPhoto(this)"/>
      <img id="previewImg" alt="Preview"/>
      <div class="msg" id="registerMsg"></div>
      <div class="btn-row" style="margin-top:10px">
        <button class="btn btn-green" onclick="submitRegister()" style="flex:1">Register</button>
        <button class="btn btn-gray" onclick="closeModal('registerModal')" style="flex:1">Cancel</button>
      </div>
    </div>
  </div>
</div>

<script>
function updateClock(){document.getElementById('clock').textContent=new Date().toLocaleString();}
updateClock(); setInterval(updateClock,1000);

document.getElementById('logDate').valueAsDate = new Date();

async function refreshPresence(){
  try{
    const res=await fetch('/api/presence?t='+Date.now());
    const d=await res.json();
    document.getElementById('presentCount').textContent=d.present_count;
    document.getElementById('knownCount').textContent=d.known_count;
    document.getElementById('runStatus').textContent = d.running ? 'Running' : 'Stopped';
    document.getElementById('connDot').className='status-dot '+(d.connected?'on':'off');
    document.getElementById('connText').textContent = d.running ? (d.connected?'Camera connected':'Connecting...') : 'Stopped';

    const list=document.getElementById('peopleList');
    if(!d.people.length){ list.innerHTML='<p class="no-rec">No one detected yet.</p>'; return; }
    list.innerHTML = d.people.map(p=>{
      const badge = p.status==='IN'
        ? '<span class="badge here">HERE</span>'
        : '<span class="badge left">LEFT '+ (p.left_at||'') +'</span>';
      const kindBadge = p.kind==='Unknown' ? '<span class="badge unknown">UNKNOWN</span>' : '';
      const mins = Math.floor(p.duration_seconds/60), secs = p.duration_seconds%60;
      const dur = mins>0 ? mins+'m '+secs+'s' : secs+'s';
      const img = p.thumbnail || '';
      return `<div class="person">
        <img src="${img}" onerror="this.style.opacity=0"/>
        <div class="person-info">
          <div class="person-name">${p.name} ${badge} ${kindBadge}</div>
          <div class="person-times">Arrived ${p.first_seen} &middot; ${p.status==='IN'?'still here':'left '+p.left_at} &middot; ${dur}</div>
        </div>
      </div>`;
    }).join('');
  }catch(e){ console.error(e); }
}

async function loadLog(){
  const date=document.getElementById('logDate').value;
  const res=await fetch('/api/log?date='+date+'&t='+Date.now());
  const d=await res.json();
  document.getElementById('todayCount').textContent = d.count;
  const cont=document.getElementById('logContainer');
  if(!d.records.length){ cont.innerHTML='<p class="no-rec">No detections logged for this date.</p>'; return; }
  cont.innerHTML = `<table><thead><tr><th>Name</th><th>Time</th><th>Camera</th><th>Status</th></tr></thead>
    <tbody>${d.records.map(r=>`<tr><td>${r.Name}</td><td>${r.Time}</td><td>${r.Camera||''}</td><td>${r.Status}</td></tr>`).join('')}</tbody></table>`;
}

async function controlDetection(action){
  showCtrl('Working...','');
  try{
    const res=await fetch('/api/control/'+action,{method:'POST'});
    const d=await res.json();
    showCtrl(d.running?'Detection running.':'Detection stopped.','success');
    document.getElementById('camFeed').src='/video_feed?t='+Date.now();
  }catch(e){ showCtrl('Error: '+e,'error'); }
}

async function reloadFaces(){
  showCtrl('Reloading known faces...','');
  try{
    const res=await fetch('/api/reload_faces',{method:'POST'});
    const d=await res.json();
    showCtrl('Loaded '+d.count+' known face(s).','success');
  }catch(e){ showCtrl('Error: '+e,'error'); }
}

function showCtrl(t,cls){
  const el=document.getElementById('ctrlMsg');
  el.textContent=t; el.className='msg '+cls;
  setTimeout(()=>{el.textContent='';},4000);
}

function closeModal(id){ document.getElementById(id).classList.remove('show'); }

async function openSettings(){
  const res=await fetch('/api/settings');
  const cfg=await res.json();
  document.getElementById('s_camera_name').value = cfg.camera.name || '';
  document.getElementById('s_camera_source').value = cfg.camera.source || '';
  document.getElementById('s_tolerance').value = cfg.detection.tolerance ?? 0.5;
  document.getElementById('s_cooldown').value = cfg.detection.cooldown_seconds ?? 60;
  document.getElementById('s_presence').value = cfg.detection.presence_timeout_seconds ?? 20;
  document.getElementById('s_everyn').value = cfg.detection.process_every_n_frames ?? 3;
  document.getElementById('s_logunknown').value = String(cfg.detection.log_unknown ?? true);
  document.getElementById('settingsModal').classList.add('show');
}

async function saveSettings(){
  const payload = {
    camera: { name: document.getElementById('s_camera_name').value, source: document.getElementById('s_camera_source').value },
    detection: {
      tolerance: parseFloat(document.getElementById('s_tolerance').value),
      cooldown_seconds: parseInt(document.getElementById('s_cooldown').value),
      presence_timeout_seconds: parseInt(document.getElementById('s_presence').value),
      process_every_n_frames: parseInt(document.getElementById('s_everyn').value),
      log_unknown: document.getElementById('s_logunknown').value === 'true'
    }
  };
  try{
    const res=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const d=await res.json();
    document.getElementById('settingsMsg').textContent='Saved.';
    document.getElementById('settingsMsg').className='msg success';
    setTimeout(()=>closeModal('settingsModal'),900);
  }catch(e){
    document.getElementById('settingsMsg').textContent='Error: '+e;
    document.getElementById('settingsMsg').className='msg error';
  }
}

function openRegister(){
  document.getElementById('r_name').value='';
  document.getElementById('r_file').value='';
  document.getElementById('previewImg').style.display='none';
  document.getElementById('registerMsg').textContent='';
  document.getElementById('registerModal').classList.add('show');
}
function previewPhoto(input){
  const file=input.files[0]; if(!file)return;
  const r=new FileReader();
  r.onload=e=>{ const img=document.getElementById('previewImg'); img.src=e.target.result; img.style.display='block'; };
  r.readAsDataURL(file);
}
async function submitRegister(){
  const name=document.getElementById('r_name').value.trim();
  const file=document.getElementById('r_file').files[0];
  const msg=document.getElementById('registerMsg');
  if(!name){ msg.textContent='Enter a name.'; msg.className='msg error'; return; }
  if(!file){ msg.textContent='Choose a photo.'; msg.className='msg error'; return; }
  const reader=new FileReader();
  reader.onload=async (e)=>{
    msg.textContent='Registering...'; msg.className='msg';
    try{
      const res=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({name,image:e.target.result})});
      const d=await res.json();
      if(d.ok){ msg.textContent=d.message; msg.className='msg success'; setTimeout(()=>closeModal('registerModal'),1200); }
      else { msg.textContent=d.error; msg.className='msg error'; }
    }catch(err){ msg.textContent='Error: '+err; msg.className='msg error'; }
  };
  reader.readAsDataURL(file);
}

document.querySelectorAll('.modal-bg').forEach(m=>{
  m.addEventListener('click',e=>{ if(e.target===m) m.classList.remove('show'); });
});

loadLog();
refreshPresence(); setInterval(refreshPresence,2000);
</script>
</body>
</html>
"""


@app.route("/")
def index():
    return render_template_string(HTML)


if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  AI Face Detection - Web Dashboard")
    print("  Open: http://localhost:5000")
    print("=" * 50 + "\n")
    engine.start()
    app.run(debug=False, host="0.0.0.0", port=5000, threaded=True)
