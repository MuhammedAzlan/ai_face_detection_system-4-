# AI Face Detection System — NVR / IP Camera Edition

Watches a live feed from your NVR/IP camera and, whenever a person moves in
front of it, detects their face and logs **who** and **what time** they
were seen. Not attendance — a running detection log, e.g.:

```
Name        Date        Time      Camera            Status
Shariq      2026-09-19  09:02:15  Front Gate Camera  Recognized
Azlan       2026-09-19  09:05:43  Front Gate Camera  Recognized
Unknown     2026-09-19  09:11:02  Front Gate Camera  Unknown
Shariq      2026-09-19  13:40:07  Front Gate Camera  Recognized   <- back again later
```

## Web Dashboard (new)

`app.py` is a browser UI — the easiest way to use this day-to-day.

**Start it:** `start_web.bat` (or `menu.bat` → option 1), then open
http://localhost:5000 (it opens automatically).

**What it shows:**
- Live camera feed with name boxes drawn on it
- **Who's on Camera** — everyone currently or recently seen, each with a
  face thumbnail, the time they **arrived**, and either "still here" or
  "left HH:MM:SS" once they've been out of frame longer than
  `presence_timeout_seconds` (in config.json)
- Today's detection log as a table, filterable by date
- **Start/Stop** buttons to control detection without touching a .bat file
- **Register Face** — upload a photo of a new person right from the browser
- **Settings** — edit camera URL, tolerance, cooldown, etc. from a form
  instead of hand-editing `config.json`

Stop it with `stop_web.bat` (or menu option 2).

The plain console version (`detector.py` / `start.bat` / `stop.bat`) still
works exactly as before if you'd rather not run a browser dashboard — the
two don't run at the same time against the same camera, so use one or the
other.

## Troubleshooting: "401 Unauthorized" on the RTSP connection

This means your NVR is rejecting the login in `config.json`, not a bug in
the code. A few things to check, **in this order**, before retrying:

1. **Stop retrying for a minute.** The updated code now backs off after 3
   failed attempts instead of retrying every 5 seconds — repeated failed
   RTSP logins can trigger an account lockout on Dahua/Hikvision NVRs,
   which then causes 401s even with the *correct* password until it clears.
2. **Test the exact URL in VLC first** (Media → Open Network Stream) before
   putting it back in `config.json`. If it fails in VLC too, it's a
   camera/network problem, not this app.
3. **Double-check credentials** — exact case, no typos, no trailing spaces.
   If the password has special characters like `@ : / ?`, they need to be
   URL-encoded (e.g. `@` → `%40`).
4. **Check the NVR's own Network → RTSP settings page** for the exact path
   it expects — the `channel=1&subtype=0` style path is Dahua's default,
   but some models/firmware customize it.
5. **Check whether the account is locked** — log into the NVR's web UI
   directly with the same credentials. If that also fails, it's locked or
   the password is wrong, not an RTSP-specific issue.
6. Some NVRs require a **separate RTSP/media user** rather than the admin
   web login — check your NVR's user management page.

## What changed from the original version

- **Camera source**: was webcam-only. Now reads an RTSP stream from your
  NVR/IP camera, with auto-reconnect if the stream drops.
- **Logging**: was "mark present once per day". Now logs **every**
  appearance, with a configurable cooldown per person (default 60s) so a
  single visit doesn't spam the log, but a second visit later still gets
  logged.
- **Settings**: was hardcoded at the top of the .py files. Now all in
  `config.json` — no code editing.
- **Start/stop**: new `start.bat` / `stop.bat` run detection in the
  background and stop it cleanly. `menu.bat` ties everything together in
  one simple screen.
- Removed a hardcoded IP-camera username/password that was sitting in the
  old `app.py`'s HTML — that should never ship in code. Camera credentials
  now live only in your local `config.json`.

## Folder structure

```
ai_face_detection_system/
├── config.json          <- camera URL, sensitivity, cooldown - EDIT THIS
├── app.py                 <- web dashboard (Flask) - recommended way to use this
├── engine.py               <- shared detection engine used by app.py
├── detector.py            <- console-only version (no browser needed)
├── register_face.py      <- add a known person
├── view_report.py        <- view / export detection logs
├── requirements.txt
├── menu.bat               <- easiest way to use everything
├── install.bat            <- one-time setup
├── start_web.bat / stop_web.bat  <- run the web dashboard in the background
├── start.bat / stop.bat          <- run the console version in the background
├── register_face.bat / view_report.bat
├── utils/
│   ├── camera_stream.py   <- threaded RTSP reader with auto-reconnect
│   ├── face_loader.py
│   └── logger.py
├── known_faces/           <- put reference photos here
└── detection_logs/        <- daily CSV logs (auto-created)
```

## Setup (Windows)

1. **Install Python 3.10+** if you don't have it (check "Add to PATH" during install).
2. Double-click **`install.bat`** (or `menu.bat` → option 5).
   - If `dlib` fails to build: download a prebuilt wheel from
     https://github.com/z-mahmud22/Dlib_Windows_Python3.x and run
     `pip install dlib-19.x.x-cpXX-win_amd64.whl`, then re-run install.bat.
3. **Edit `config.json`** with your NVR/camera's RTSP URL. Get this from
   your NVR's network/RTSP settings page. Common formats:
   - Hikvision: `rtsp://user:pass@192.168.1.64:554/Streaming/Channels/101`
   - Dahua: `rtsp://user:pass@192.168.1.64:554/cam/realmonitor?channel=1&subtype=0`
   - Generic ONVIF: check your NVR's manual for its RTSP path.
   You can test the URL first in VLC (Media → Open Network Stream) before
   putting it in config.json.
4. Register known people — double-click **`register_face.bat`**, or:
   ```
   python register_face.py --name "John Doe" --file path\to\photo.jpg
   ```
   (a clear, front-facing photo works fine — no need for a live webcam.)

## Running it

Easiest: double-click **`menu.bat`** and pick an option.

Or directly:
- **`start.bat`** — starts detection in the background, saves its process
  ID to `detector.pid` so it can be stopped cleanly later.
- **`stop.bat`** — stops it.
- **`python detector.py`** — run it directly in a console window (shows
  the live preview, Q to quit, R to reload known faces).

## Viewing detections

- `view_report.bat`, or `python view_report.py` — today's detections
- `python view_report.py --date 2026-09-19` — a specific day
- `python view_report.py --person "John Doe"` — every sighting of one person
- `python view_report.py --summary` — one line per day
- `python view_report.py --export` — merges every day into `full_report.csv`

## Key settings (`config.json`)

| Setting | What it does |
|---|---|
| `camera.source` | RTSP URL of your NVR channel (or `0` for a local webcam) |
| `detection.tolerance` | Match strictness. Lower = stricter (0.4–0.6 typical) |
| `detection.cooldown_seconds` | Minimum gap before the same person is logged again |
| `detection.process_every_n_frames` | Skip frames to reduce CPU load (RTSP + face recognition is heavy) |
| `detection.log_unknown` | Also log unrecognized faces as "Unknown" |
| `display.show_window` | Set `false` for headless/background running (no preview window) |

## A couple of practical notes

- **Performance**: `face_recognition` (dlib) is CPU-heavy. On a modest PC,
  expect maybe 3–8 frames/sec of actual detection — fine for a doorway/gate
  camera, not fine for a busy area with fast-moving crowds. Raising
  `process_every_n_frames` or lowering `scale_factor` trades accuracy for
  speed.
- **Multiple cameras**: run a second copy of this folder with a different
  `config.json` (different `camera.source` and `camera.name`), or extend
  `detector.py` to loop over several `CameraStream` instances if you want
  one process watching several channels at once.
- **Privacy/compliance**: continuous face detection on a camera feed is
  regulated in a lot of places (workplace monitoring notices, local
  privacy law, etc.). Worth checking what applies before deploying this
  somewhere people don't expect to be identified.

## License

MIT — free to use and modify for personal or commercial projects.
