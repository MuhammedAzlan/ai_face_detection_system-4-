"""
engine.py
=========
The detection engine behind the web dashboard (app.py).

Runs the camera + face-recognition loop in a background thread and keeps
two things updated for the UI to read at any moment:

  1. The latest annotated video frame (JPEG bytes), for the live preview.
  2. A "presence" table: for every person currently or recently seen,
     when they FIRST appeared, when they were LAST seen, whether they're
     still "IN" frame or have "left" (no longer seen for
     detection.presence_timeout_seconds), and a small face thumbnail.

detector.py (the CLI version) is separate and doesn't use this file -
this one exists specifically to power the web UI's "who's here / when
did they arrive or leave" view.
"""

import os
import json
import time
import base64
import threading
from datetime import datetime

import cv2
import numpy as np
import face_recognition

from utils.face_loader import load_known_faces
from utils.camera_stream import CameraStream
from utils.logger import log_detection

CONFIG_PATH = "config.json"


def load_config() -> dict:
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


class DetectionEngine:
    def __init__(self, config_path: str = CONFIG_PATH):
        self.config_path = config_path
        self.cfg = load_config()

        self._frame_lock = threading.Lock()
        self._presence_lock = threading.Lock()

        self.running = False
        self.thread = None
        self.stream = None
        self.connected = False

        self.known_encodings = []
        self.known_names = []

        self._latest_jpeg = None

        # name -> {name, kind, status ("IN"/"OUT"), first_seen, last_seen,
        #          left_at, thumbnail (base64 data URI)}
        self.presence = {}

    # ---------------- lifecycle ----------------

    def reload_config(self):
        self.cfg = load_config()

    def reload_faces(self) -> int:
        path_cfg = self.cfg["paths"]
        encs, names = load_known_faces(path_cfg["known_faces_dir"])
        self.known_encodings = encs
        self.known_names = names
        return len(names)

    def start(self):
        if self.running:
            return
        self.cfg = load_config()
        self.reload_faces()

        cam_cfg = self.cfg["camera"]
        self.stream = CameraStream(
            source=cam_cfg["source"],
            reconnect_delay=cam_cfg.get("reconnect_delay_seconds", 5),
            name=cam_cfg.get("name", "Camera"),
        ).start()

        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=3)
        if self.stream is not None:
            self.stream.stop()
            self.stream = None
        with self._frame_lock:
            self._latest_jpeg = None

    def is_running(self) -> bool:
        return self.running

    # ---------------- read access for the web layer ----------------

    def get_jpeg(self):
        with self._frame_lock:
            return self._latest_jpeg

    def get_presence_snapshot(self) -> dict:
        with self._presence_lock:
            return {k: dict(v) for k, v in self.presence.items()}

    # ---------------- main loop ----------------

    def _loop(self):
        det_cfg = self.cfg["detection"]
        tolerance = det_cfg.get("tolerance", 0.5)
        scale = det_cfg.get("scale_factor", 0.25)
        every_n = max(1, det_cfg.get("process_every_n_frames", 3))
        cooldown = det_cfg.get("cooldown_seconds", 60)
        log_unknown = det_cfg.get("log_unknown", True)
        presence_timeout = det_cfg.get("presence_timeout_seconds", 20)
        camera_name = self.cfg["camera"].get("name", "Camera")

        last_logged = {}
        last_boxes = []
        frame_count = 0

        while self.running:
            frame = self.stream.read() if self.stream else None
            self.connected = self.stream.is_connected() if self.stream else False

            if frame is None:
                self._check_departures(presence_timeout)
                time.sleep(0.03)
                continue

            frame_count += 1
            run_this_frame = (frame_count % every_n == 0)

            if run_this_frame:
                small = cv2.resize(frame, (0, 0), fx=scale, fy=scale)
                rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                face_locations = face_recognition.face_locations(rgb_small)
                face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

                last_boxes = []
                now_ts = time.time()

                for enc, loc in zip(face_encodings, face_locations):
                    name = "Unknown"
                    color = (0, 0, 220)
                    kind = "Unknown"

                    if self.known_encodings:
                        distances = face_recognition.face_distance(self.known_encodings, enc)
                        best_idx = int(np.argmin(distances))
                        if distances[best_idx] <= tolerance:
                            name = self.known_names[best_idx]
                            color = (0, 200, 0)
                            kind = "Recognized"

                    scale_back = int(round(1 / scale))
                    top, right, bottom, left = [v * scale_back for v in loc]
                    last_boxes.append((name, color, (top, right, bottom, left)))

                    if kind == "Unknown" and not log_unknown:
                        continue

                    thumb = self._make_thumbnail(frame, (top, right, bottom, left))
                    self._update_presence(name, kind, now_ts, thumb)

                    prior = last_logged.get(name, 0)
                    if now_ts - prior >= cooldown:
                        log_detection(name, camera_name, kind)
                        last_logged[name] = now_ts

            self._draw_overlay(frame, last_boxes, camera_name)

            ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            if ok:
                with self._frame_lock:
                    self._latest_jpeg = buf.tobytes()

            self._check_departures(presence_timeout)

    def _draw_overlay(self, frame, boxes, camera_name):
        for name, color, (top, right, bottom, left) in boxes:
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.rectangle(frame, (left, bottom - 34), (right, bottom), color, cv2.FILLED)
            cv2.putText(frame, name, (left + 6, bottom - 8),
                        cv2.FONT_HERSHEY_DUPLEX, 0.7, (255, 255, 255), 1)

        status_color = (0, 220, 255) if self.connected else (0, 0, 220)
        cv2.putText(frame, datetime.now().strftime("%Y-%m-%d  %H:%M:%S"), (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
        cv2.putText(frame, camera_name, (10, 56),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, status_color, 1)

    def _make_thumbnail(self, frame, box, size: int = 96):
        top, right, bottom, left = box
        h, w = frame.shape[:2]
        top, left = max(0, top), max(0, left)
        bottom, right = min(h, bottom), min(w, right)
        if bottom <= top or right <= left:
            return None
        try:
            crop = cv2.resize(frame[top:bottom, left:right], (size, size))
            ok, buf = cv2.imencode(".jpg", crop)
            if not ok:
                return None
            return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode("ascii")
        except Exception:
            return None

    def _update_presence(self, name, kind, now_ts, thumb):
        with self._presence_lock:
            entry = self.presence.get(name)
            if entry is None or entry.get("status") == "OUT":
                self.presence[name] = {
                    "name": name,
                    "kind": kind,
                    "status": "IN",
                    "first_seen": now_ts,
                    "last_seen": now_ts,
                    "left_at": None,
                    "thumbnail": thumb or (entry.get("thumbnail") if entry else None),
                }
            else:
                entry["last_seen"] = now_ts
                if thumb:
                    entry["thumbnail"] = thumb

    def _check_departures(self, presence_timeout):
        now_ts = time.time()
        with self._presence_lock:
            for entry in self.presence.values():
                if entry["status"] == "IN" and now_ts - entry["last_seen"] > presence_timeout:
                    entry["status"] = "OUT"
                    entry["left_at"] = entry["last_seen"]
