"""
app.py
======
Web dashboard for the AI Face Detection System.

Shows the live camera feed, who's currently in frame vs. who has left
(with arrival/departure times and a face thumbnail), today's detection
log, and lets you edit camera settings or register a new face - all
from the browser instead of editing files.

Run:
    python app.py
Then open:
    http://localhost:5000
"""

import os
import time
import base64
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
import psutil
from flask import Flask, Response, jsonify, request, render_template_string, send_file

from engine import DetectionEngine, load_config, save_config
from utils.logger import LOGS_DIR, get_person_history, purge_old_logs
from report import generate_daily_report_pdf
import register_face

app = Flask(__name__)
engine = DetectionEngine()
_process = psutil.Process(os.getpid())


def _clean_records(records: list) -> list:
    """Replace pandas/numpy NaN with None so the JSON we emit is strictly
    valid - a bare NaN is accepted by Python's json module but rejected by
    a browser's JSON.parse, which would silently break every fetch() call."""
    import math
    def clean_val(v):
        if isinstance(v, float) and math.isnan(v):
            return None
        return v
    return [{k: clean_val(v) for k, v in row.items()} for row in records]


# ───────────────────────────── video stream ─────────────────────────────

def _placeholder_jpeg(message: str) -> bytes:
    frame = np.zeros((360, 640, 3), dtype=np.uint8)
    cv2.putText(frame, message, (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (60, 60, 220), 2)
    ok, buf = cv2.imencode(".jpg", frame)
    return buf.tobytes()


@app.route("/video_feed")
def video_feed():
    def gen():
        boundary = b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
        while True:
            if not engine.is_running():
                data = _placeholder_jpeg("Detection is stopped - press Start")
            else:
                jpeg = engine.get_jpeg()
                data = jpeg if jpeg else _placeholder_jpeg("Connecting to camera...")
            yield boundary + data + b"\r\n"
            time.sleep(0.05)

    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")


# ───────────────────────────── JSON API ─────────────────────────────

@app.route("/api/presence")
def api_presence():
    snap = engine.get_presence_snapshot()
    now = time.time()
    people = []
    for name, e in sorted(snap.items(), key=lambda kv: -kv[1]["last_seen"]):
        left_at = e["left_at"]
        people.append({
            "name": e["name"],
            "kind": e["kind"],
            "status": e["status"],
            "confidence": round(e["confidence"], 1) if e.get("confidence") is not None else None,
            "first_seen": datetime.fromtimestamp(e["first_seen"]).strftime("%H:%M:%S"),
            "last_seen": datetime.fromtimestamp(e["last_seen"]).strftime("%H:%M:%S"),
            "left_at": datetime.fromtimestamp(left_at).strftime("%H:%M:%S") if left_at else None,
            "duration_seconds": int((left_at or now) - e["first_seen"]),
            "thumbnail": e["thumbnail"],
        })
    return jsonify({
        "running": engine.is_running(),
        "connected": bool(engine.connected),
        "present_count": sum(1 for p in people if p["status"] == "IN"),
        "known_count": len(engine.known_names),
        "people": people,
    })


@app.route("/api/stats")
def api_stats():
    stats = engine.get_stats()
    stats["ram_mb"] = round(_process.memory_info().rss / (1024 * 1024), 1)
    stats["cpu_percent"] = psutil.cpu_percent(interval=None)
    return jsonify(stats)


@app.route("/api/diagnostics", methods=["POST"])
def api_diagnostics():
    result = engine.run_diagnostics()
    return jsonify(result)


@app.route("/debug_image/<path:filename>")
def debug_image(filename):
    debug_dir = os.path.abspath(os.path.join(LOGS_DIR, "debug"))
    safe_name = os.path.basename(filename)  # no path traversal via ../..
    full_path = os.path.join(debug_dir, safe_name)
    if not os.path.exists(full_path):
        return "Not found", 404
    return send_file(full_path, mimetype="image/jpeg")


@app.route("/api/person/<path:name>")
def api_person(name):
    snap = engine.get_presence_snapshot()
    live = snap.get(name)
    history_df = get_person_history(name, limit=50)
    history = _clean_records(history_df.to_dict(orient="records")) if not history_df.empty else []
    return jsonify({
        "name": name,
        "live": {
            "status": live["status"],
            "kind": live["kind"],
            "confidence": round(live["confidence"], 1) if live and live.get("confidence") is not None else None,
            "first_seen": datetime.fromtimestamp(live["first_seen"]).strftime("%H:%M:%S"),
            "last_seen": datetime.fromtimestamp(live["last_seen"]).strftime("%H:%M:%S"),
            "left_at": datetime.fromtimestamp(live["left_at"]).strftime("%H:%M:%S") if live.get("left_at") else None,
            "thumbnail": live["thumbnail"],
        } if live else None,
        "history": history,
    })


@app.route("/api/log")
def api_log():
    date = request.args.get("date") or datetime.now().strftime("%Y-%m-%d")
    log_file = os.path.join(LOGS_DIR, f"{date}.csv")
    records = []
    if os.path.exists(log_file):
        df = pd.read_csv(log_file)
        records = _clean_records(df.to_dict(orient="records"))
    return jsonify({"date": date, "count": len(records), "records": records})


@app.route("/api/export.csv")
def api_export_csv():
    date = request.args.get("date") or datetime.now().strftime("%Y-%m-%d")
    log_file = os.path.join(LOGS_DIR, f"{date}.csv")
    if not os.path.exists(log_file):
        return "No log found for that date.", 404
    return send_file(
        os.path.abspath(log_file), mimetype="text/csv",
        as_attachment=True, download_name=f"detections_{date}.csv"
    )


@app.route("/api/report.pdf")
def api_report_pdf():
    date = request.args.get("date") or datetime.now().strftime("%Y-%m-%d")
    cfg = load_config()
    camera_name = cfg.get("camera", {}).get("name", "")
    pdf_bytes = generate_daily_report_pdf(date, camera_name)
    from io import BytesIO
    return send_file(
        BytesIO(pdf_bytes), mimetype="application/pdf",
        as_attachment=True, download_name=f"report_{date}.pdf"
    )


@app.route("/api/cameras", methods=["GET"])
def api_cameras_list():
    cfg = load_config()
    return jsonify({
        "active": cfg.get("camera", {}),
        "saved": cfg.get("cameras", []),
    })


@app.route("/api/cameras/switch", methods=["POST"])
def api_cameras_switch():
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    source = data.get("source")
    save_as = bool(data.get("save"))

    if not name or source in (None, ""):
        return jsonify({"ok": False, "error": "Camera name and source are required."})

    # webcam index "0" should stay an int, RTSP URLs stay strings
    if isinstance(source, str) and source.strip().isdigit():
        source = int(source.strip())

    if save_as:
        cfg = load_config()
        cameras = cfg.setdefault("cameras", [])
        existing = next((c for c in cameras if c.get("name") == name), None)
        if existing:
            existing["source"] = source
        else:
            cameras.append({"name": name, "source": source})
        save_config(cfg)

    engine.switch_camera(name, source)
    return jsonify({"ok": True, "active": {"name": name, "source": source}})


@app.route("/api/logs/purge", methods=["POST"])
def api_logs_purge():
    data = request.get_json(force=True, silent=True) or {}
    days = int(data.get("retention_days") or 0)
    removed = purge_old_logs(days)
    return jsonify({"ok": True, "days_removed": removed})


@app.route("/api/control/start", methods=["POST"])
def api_control_start():
    engine.start()
    return jsonify({"ok": True, "running": engine.is_running()})


@app.route("/api/control/stop", methods=["POST"])
def api_control_stop():
    engine.stop()
    return jsonify({"ok": True, "running": engine.is_running()})


@app.route("/api/reload_faces", methods=["POST"])
def api_reload_faces():
    count = engine.reload_faces()
    return jsonify({"ok": True, "count": count, "names": engine.known_names})


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "GET":
        return jsonify(load_config())

    data = request.get_json(force=True, silent=True) or {}
    cfg = load_config()
    for section in ("camera", "detection", "paths", "display"):
        if section in data and isinstance(data[section], dict):
            cfg.setdefault(section, {}).update(data[section])
    save_config(cfg)
    engine.reload_config()
    return jsonify({"ok": True, "config": cfg})


@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    image_b64 = data.get("image") or ""

    if not name:
        return jsonify({"ok": False, "error": "Name is required."})
    if not image_b64:
        return jsonify({"ok": False, "error": "Photo is required."})

    try:
        if "," in image_b64:
            image_b64 = image_b64.split(",", 1)[1]
        img_bytes = base64.b64decode(image_b64)
        arr = np.frombuffer(img_bytes, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return jsonify({"ok": False, "error": "Could not read that image."})

        os.makedirs("known_faces", exist_ok=True)
        tmp_path = os.path.join("known_faces", "_upload_tmp.jpg")
        cv2.imwrite(tmp_path, img)

        ok = register_face.register_from_file(name, tmp_path)
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

        if not ok:
            return jsonify({"ok": False, "error": "No face detected in that photo. Use a clearer, front-facing photo."})

        count = engine.reload_faces()
        return jsonify({"ok": True, "message": f"'{name}' registered.", "known_count": count})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


# ───────────────────────────── page ─────────────────────────────

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AI Face Detection Dashboard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#0f172a;color:#e2e8f0}
header{background:linear-gradient(135deg,#1e3a8a,#3b82f6);padding:14px 28px;
       display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px}
header h1{font-size:1.3rem;font-weight:700}
.header-right{display:flex;align-items:center;gap:14px;font-size:.85rem;color:#bfdbfe}
.container{max-width:1400px;margin:0 auto;padding:20px 16px}
.stats{display:flex;gap:14px;margin-bottom:20px;flex-wrap:wrap}
.stat{flex:1;min-width:140px;background:#1e293b;border-radius:12px;padding:14px 18px;border-left:4px solid #3b82f6}
.stat.green{border-color:#22c55e}
.stat.yellow{border-color:#eab308}
.stat.red{border-color:#ef4444}
.stat-label{font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px}
.stat-value{font-size:1.6rem;font-weight:700;color:#f1f5f9}
.grid{display:grid;grid-template-columns:1.3fr 1fr;gap:18px}
@media(max-width:1000px){.grid{grid-template-columns:1fr}}
.card{background:#1e293b;border-radius:14px;border:1px solid #334155;overflow:hidden;margin-bottom:16px}
.card-header{padding:12px 16px;font-weight:600;font-size:.92rem;border-bottom:1px solid #334155;
             background:#162032;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.card-body{padding:14px 16px}
.cam-img{width:100%;display:block;min-height:240px;background:#0f172a}
.btn{padding:8px 14px;border:none;border-radius:8px;font-size:.8rem;font-weight:600;cursor:pointer;
     transition:all .15s;display:inline-flex;align-items:center;gap:6px}
.btn:hover{opacity:.85}
.btn-blue{background:#3b82f6;color:#fff}
.btn-green{background:#22c55e;color:#fff}
.btn-red{background:#ef4444;color:#fff}
.btn-gray{background:#334155;color:#e2e8f0}
.btn-row{display:flex;gap:8px;flex-wrap:wrap}
.badge{font-size:.68rem;padding:2px 9px;border-radius:20px;font-weight:700}
.badge.here{background:#14532d;color:#4ade80}
.badge.left{background:#3f3f1a;color:#facc15}
.badge.unknown{background:#4c1d1d;color:#f87171}
.badge.conf{background:#1e3a5f;color:#7dd3fc}
.people-list{display:flex;flex-direction:column;gap:8px;max-height:400px;overflow-y:auto}
.person{display:flex;gap:10px;align-items:center;background:#0f172a;border:1px solid #253045;
        border-radius:10px;padding:8px 10px;cursor:pointer;transition:border-color .15s}
.person:hover{border-color:#3b82f6}
.person img{width:48px;height:48px;border-radius:8px;object-fit:cover;background:#334155}
.person-info{flex:1;min-width:0}
.person-name{font-weight:600;font-size:.88rem;display:flex;align-items:center;gap:8px}
.person-times{font-size:.72rem;color:#94a3b8;margin-top:2px}
.no-rec{color:#475569;text-align:center;padding:24px;font-size:.85rem}
table{width:100%;border-collapse:collapse;font-size:.8rem}
th{text-align:left;padding:7px 8px;color:#64748b;font-size:.66rem;text-transform:uppercase;
   letter-spacing:.5px;border-bottom:1px solid #334155}
td{padding:8px;border-bottom:1px solid #1a2744}
.log-scroll{max-height:280px;overflow-y:auto}
.status-dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.status-dot.on{background:#22c55e}
.status-dot.off{background:#ef4444}
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:100;
          align-items:center;justify-content:center}
.modal-bg.show{display:flex}
.modal{background:#1e293b;border-radius:14px;border:1px solid #334155;width:460px;max-width:94vw;
       max-height:90vh;overflow-y:auto}
.modal-header{padding:14px 18px;background:#162032;border-bottom:1px solid #334155;
              display:flex;align-items:center;justify-content:space-between}
.modal-body{padding:18px}
.modal-close{background:none;border:none;color:#94a3b8;font-size:1.3rem;cursor:pointer}
.form-group{margin-bottom:12px}
.form-group label{display:block;font-size:.78rem;color:#94a3b8;margin-bottom:5px;font-weight:500}
.form-group input,.form-group select{width:100%;padding:8px 10px;background:#0f172a;
     border:1px solid #334155;border-radius:8px;color:#e2e8f0;font-size:.85rem;outline:none}
.form-group input:focus{border-color:#3b82f6}
.form-row{display:flex;gap:10px}
.form-row .form-group{flex:1}
.upload-area{border:2px dashed #334155;border-radius:10px;padding:20px;text-align:center;
             cursor:pointer;margin-bottom:10px}
.upload-area:hover{border-color:#3b82f6;background:#162032}
#previewImg{width:100%;border-radius:8px;display:none;margin-bottom:10px;max-height:200px;object-fit:cover}
.msg{font-size:.8rem;min-height:18px;margin-top:6px;font-weight:500}
.msg.success{color:#4ade80}
.msg.error{color:#f87171}
.tabbtn{padding:8px 12px;font-size:.8rem;border-radius:8px;border:1px solid #334155;
        background:#0f172a;color:#94a3b8;cursor:pointer}
.tabbtn.active{background:#3b82f6;color:#fff;border-color:#3b82f6}
.search-row{display:flex;gap:8px;padding:10px 16px;border-bottom:1px solid #334155;flex-wrap:wrap;align-items:center}
.search-row input[type=text]{flex:1;min-width:140px;padding:6px 10px;background:#0f172a;
     border:1px solid #334155;border-radius:6px;color:#e2e8f0;font-size:.78rem;outline:none}
.filter-chip{padding:5px 11px;font-size:.72rem;border-radius:20px;border:1px solid #334155;
     background:#0f172a;color:#94a3b8;cursor:pointer;font-weight:600}
.filter-chip.active{background:#3b82f6;color:#fff;border-color:#3b82f6}
.footer-bar{display:flex;gap:20px;flex-wrap:wrap;padding:10px 18px;font-size:.72rem;color:#64748b;
     background:#0b1220;border-top:1px solid #253045;margin-top:6px}
.footer-bar b{color:#94a3b8}
#hourChart{width:100%;height:90px;display:block}
.toast-wrap{position:fixed;top:16px;right:16px;z-index:200;display:flex;flex-direction:column;gap:8px}
.toast{background:#1e293b;border:1px solid #ef4444;border-left:4px solid #ef4444;border-radius:10px;
       padding:10px 16px;font-size:.82rem;box-shadow:0 4px 14px rgba(0,0,0,.4);min-width:220px;
       animation:slidein .2s ease-out}
@keyframes slidein{from{transform:translateX(20px);opacity:0}to{transform:translateX(0);opacity:1}}
.person-detail-row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #253045;font-size:.83rem}
.person-detail-row span:first-child{color:#94a3b8}
</style>
</head>
<body>

<div class="toast-wrap" id="toastWrap"></div>

<header>
  <h1>AI Face Detection Dashboard</h1>
  <div class="header-right">
    <span><span class="status-dot" id="connDot"></span> <span id="connText">-</span></span>
    <span id="clock"></span>
  </div>
</header>

<div class="container">
  <div class="stats">
    <div class="stat green"><div class="stat-label">Here Now</div><div class="stat-value" id="presentCount">-</div></div>
    <div class="stat"><div class="stat-label">Registered Faces</div><div class="stat-value" id="knownCount">-</div></div>
    <div class="stat yellow"><div class="stat-label">Detections Today</div><div class="stat-value" id="todayCount">-</div></div>
    <div class="stat" style="border-color:#a855f7"><div class="stat-label">Known / Unknown</div><div class="stat-value" style="font-size:1.2rem;padding-top:6px" id="kuRatio">- / -</div></div>
    <div class="stat red" id="statusStat"><div class="stat-label">Detection</div>
      <div class="stat-value" style="font-size:1.1rem;padding-top:5px" id="runStatus">-</div></div>
  </div>

  <div class="grid">
    <div>
      <div class="card">
        <div class="card-header">
          <span id="cameraLabel">Live Camera Feed</span>
          <div class="btn-row">
            <button class="btn btn-gray" onclick="openCameraSwitch()">Switch Camera</button>
            <button class="btn btn-green" onclick="controlDetection('start')">Start</button>
            <button class="btn btn-red" onclick="controlDetection('stop')">Stop</button>
          </div>
        </div>
        <img id="camFeed" class="cam-img" src="/video_feed" alt="Camera feed"/>
        <div class="footer-bar">
          <span><b id="fpsVal">-</b> fps</span>
          <span>RAM <b id="ramVal">-</b> MB</span>
          <span>CPU <b id="cpuVal">-</b>%</span>
          <span>Camera: <b id="camNameVal">-</b></span>
        </div>
      </div>

      <div class="card">
        <div class="card-header">Detections by Hour (today)</div>
        <div class="card-body"><canvas id="hourChart"></canvas></div>
      </div>

      <div class="card">
        <div class="card-header">
          Detection Log
          <div class="btn-row">
            <input type="date" id="logDate" style="padding:5px 8px;border-radius:6px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;font-size:.78rem"/>
            <button class="btn btn-gray" onclick="loadLog()">Refresh</button>
            <button class="btn btn-blue" onclick="downloadCSV()">CSV</button>
            <button class="btn btn-blue" onclick="downloadPDF()">PDF Report</button>
          </div>
        </div>
        <div class="search-row">
          <input type="text" id="logSearch" placeholder="Search by name..." oninput="renderLog()"/>
          <button class="filter-chip active" data-f="all" onclick="setLogFilter('all',this)">All</button>
          <button class="filter-chip" data-f="Recognized" onclick="setLogFilter('Recognized',this)">Recognized</button>
          <button class="filter-chip" data-f="Unknown" onclick="setLogFilter('Unknown',this)">Unknown</button>
        </div>
        <div class="card-body log-scroll">
          <div id="logContainer"><p class="no-rec">Loading...</p></div>
        </div>
      </div>
    </div>

    <div>
      <div class="card">
        <div class="card-header">
          Controls
        </div>
        <div class="card-body">
          <div class="btn-row" style="margin-bottom:0">
            <button class="btn btn-blue" onclick="reloadFaces()">Reload Faces</button>
            <button class="btn btn-blue" onclick="openRegister()">Register Face</button>
            <button class="btn btn-gray" onclick="openSettings()">Settings</button>
          </div>
          <div class="msg" id="ctrlMsg"></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          Not Detecting Anyone?
          <button class="btn btn-gray" onclick="runDiagnostics()">Run Diagnostics</button>
        </div>
        <div class="card-body">
          <p style="font-size:.75rem;color:#64748b;margin-bottom:8px">
            Tests the current camera frame at several detection settings and shows
            exactly how many faces each one finds - so you can tell a tuning problem
            from an angle/visibility problem instead of guessing.
          </p>
          <div id="diagResults"></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">Who's on Camera</div>
        <div class="card-body">
          <div class="people-list" id="peopleList"><p class="no-rec">No one detected yet.</p></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Settings Modal -->
<div class="modal-bg" id="settingsModal">
  <div class="modal">
    <div class="modal-header"><h3>Camera & Detection Settings</h3>
      <button class="modal-close" onclick="closeModal('settingsModal')">&times;</button></div>
    <div class="modal-body">
      <div class="form-group"><label>Camera Name</label><input id="s_camera_name"/></div>
      <div class="form-group"><label>RTSP / Camera Source URL</label><input id="s_camera_source" placeholder="rtsp://user:pass@ip:554/..."/></div>
      <div class="form-row">
        <div class="form-group"><label>Tolerance (lower=stricter)</label><input id="s_tolerance" type="number" step="0.05"/></div>
        <div class="form-group"><label>Cooldown (sec, log repeat)</label><input id="s_cooldown" type="number"/></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Presence timeout (sec)</label><input id="s_presence" type="number"/></div>
        <div class="form-group"><label>Process every N frames</label><input id="s_everyn" type="number"/></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Detection scale (higher = bigger/easier faces, slower)</label><input id="s_scale" type="number" step="0.05" min="0.1" max="1"/></div>
        <div class="form-group"><label>Upsample passes (raise if faces are missed)</label><input id="s_upsample" type="number" min="0" max="3"/></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Model</label>
          <select id="s_model"><option value="hog">hog (fast, CPU)</option><option value="cnn">cnn (accurate, slow without GPU)</option></select>
        </div>
        <div class="form-group">
          <label>Log unrecognized faces as "Unknown"</label>
          <select id="s_logunknown"><option value="true">Yes</option><option value="false">No</option></select>
        </div>
      </div>
      <div class="form-group"><label>Keep logs & snapshots for (days, 0 = forever)</label><input id="s_retention" type="number" min="0"/></div>
      <p style="font-size:.72rem;color:#64748b;margin:-6px 0 12px">
        If people are visible on camera but not being detected (common with wide/overhead
        shots where faces are small or angled away from the camera), try raising the
        detection scale and upsample passes first - they cost CPU/speed but catch smaller faces.
      </p>
      <div class="msg" id="settingsMsg"></div>
      <div class="btn-row" style="margin-top:14px">
        <button class="btn btn-green" onclick="saveSettings()" style="flex:1">Save & Apply</button>
        <button class="btn btn-gray" onclick="closeModal('settingsModal')" style="flex:1">Cancel</button>
      </div>
      <p style="font-size:.72rem;color:#64748b;margin-top:10px">
        Changing the camera source takes effect the next time you press Start (stop first if it's already running).
      </p>
    </div>
  </div>
</div>

<!-- Register Modal -->
<div class="modal-bg" id="registerModal">
  <div class="modal">
    <div class="modal-header"><h3>Register a New Face</h3>
      <button class="modal-close" onclick="closeModal('registerModal')">&times;</button></div>
    <div class="modal-body">
      <div class="form-group"><label>Full Name</label><input id="r_name" placeholder="e.g. John Doe"/></div>
      <div class="upload-area" onclick="document.getElementById('r_file').click()">
        <div style="font-size:2rem">+</div>
        <p style="color:#64748b;font-size:.8rem;margin-top:6px">Click to select a clear, front-facing photo</p>
      </div>
      <input type="file" id="r_file" accept="image/*" style="display:none" onchange="previewPhoto(this)"/>
      <img id="previewImg" alt="Preview"/>
      <div class="msg" id="registerMsg"></div>
      <div class="btn-row" style="margin-top:10px">
        <button class="btn btn-green" onclick="submitRegister()" style="flex:1">Register</button>
        <button class="btn btn-gray" onclick="closeModal('registerModal')" style="flex:1">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Person Detail Modal -->
<div class="modal-bg" id="personModal">
  <div class="modal">
    <div class="modal-header"><h3 id="pd_name">Person</h3>
      <button class="modal-close" onclick="closeModal('personModal')">&times;</button></div>
    <div class="modal-body">
      <div style="display:flex;gap:14px;align-items:center;margin-bottom:12px">
        <img id="pd_thumb" style="width:72px;height:72px;border-radius:10px;object-fit:cover;background:#334155"/>
        <div id="pd_badges"></div>
      </div>
      <div class="person-detail-row"><span>Status</span><span id="pd_status">-</span></div>
      <div class="person-detail-row"><span>Confidence</span><span id="pd_conf">-</span></div>
      <div class="person-detail-row"><span>Arrived</span><span id="pd_arrived">-</span></div>
      <div class="person-detail-row"><span>Last seen / Left</span><span id="pd_left">-</span></div>
      <h4 style="margin:14px 0 6px;font-size:.85rem;color:#94a3b8">Historical Sightings</h4>
      <div class="log-scroll" style="max-height:220px">
        <div id="pd_history"><p class="no-rec">Loading...</p></div>
      </div>
    </div>
  </div>
</div>

<!-- Camera Switch Modal -->
<div class="modal-bg" id="cameraModal">
  <div class="modal">
    <div class="modal-header"><h3>Switch Camera</h3>
      <button class="modal-close" onclick="closeModal('cameraModal')">&times;</button></div>
    <div class="modal-body">
      <div class="form-group" id="cam_saved_group" style="display:none">
        <label>Saved Cameras</label>
        <select id="cam_saved" onchange="fillCameraForm()"></select>
      </div>
      <div class="form-group"><label>Camera Name</label><input id="cam_name" placeholder="e.g. Office Lobby"/></div>
      <div class="form-group"><label>RTSP / Camera Source URL</label><input id="cam_source" placeholder="rtsp://user:pass@ip:554/... or 0 for webcam"/></div>
      <div class="form-group" style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" id="cam_save" style="width:auto" checked/>
        <label style="margin:0" for="cam_save">Save to camera list for next time</label>
      </div>
      <div class="msg" id="cameraMsg"></div>
      <div class="btn-row" style="margin-top:12px">
        <button class="btn btn-green" onclick="submitCameraSwitch()" style="flex:1">Switch</button>
        <button class="btn btn-gray" onclick="closeModal('cameraModal')" style="flex:1">Cancel</button>
      </div>
      <p style="font-size:.72rem;color:#64748b;margin-top:10px">
        Switching stops detection briefly and reconnects to the new source. Presence history for the previous camera is cleared.
      </p>
    </div>
  </div>
</div>

<script>
function updateClock(){document.getElementById('clock').textContent=new Date().toLocaleString();}
updateClock(); setInterval(updateClock,1000);

document.getElementById('logDate').valueAsDate = new Date();

let allLogRecords = [];
let logFilterStatus = 'all';
let knownUnknownSeen = new Set();  // names already toast-alerted this session

async function refreshPresence(){
  try{
    const res=await fetch('/api/presence?t='+Date.now());
    const d=await res.json();
    document.getElementById('presentCount').textContent=d.present_count;
    document.getElementById('knownCount').textContent=d.known_count;
    document.getElementById('runStatus').textContent = d.running ? 'Running' : 'Stopped';
    document.getElementById('connDot').className='status-dot '+(d.connected?'on':'off');
    document.getElementById('connText').textContent = d.running ? (d.connected?'Camera connected':'Connecting...') : 'Stopped';

    const list=document.getElementById('peopleList');
    if(!d.people.length){ list.innerHTML='<p class="no-rec">No one detected yet.</p>'; return; }
    list.innerHTML = d.people.map(p=>{
      const badge = p.status==='IN'
        ? '<span class="badge here">HERE</span>'
        : '<span class="badge left">LEFT '+ (p.left_at||'') +'</span>';
      const kindBadge = p.kind==='Unknown' ? '<span class="badge unknown">UNKNOWN</span>' : '';
      const confBadge = p.confidence!=null ? '<span class="badge conf">'+p.confidence+'%</span>' : '';
      const mins = Math.floor(p.duration_seconds/60), secs = p.duration_seconds%60;
      const dur = mins>0 ? mins+'m '+secs+'s' : secs+'s';
      const img = p.thumbnail || '';
      return `<div class="person" onclick="openPersonDetail('${p.name.replace(/'/g,"\\'")}')">
        <img src="${img}" onerror="this.style.opacity=0"/>
        <div class="person-info">
          <div class="person-name">${p.name} ${badge} ${kindBadge} ${confBadge}</div>
          <div class="person-times">Arrived ${p.first_seen} &middot; ${p.status==='IN'?'still here':'left '+p.left_at} &middot; dwell ${dur}</div>
        </div>
      </div>`;
    }).join('');

    // toast when a brand-new unknown visitor shows up
    d.people.forEach(p=>{
      if(p.kind==='Unknown' && p.status==='IN'){
        const key=p.name+'|'+p.first_seen;
        if(!knownUnknownSeen.has(key)){
          knownUnknownSeen.add(key);
          showToast('Unrecognized face detected at '+p.first_seen);
        }
      }
    });
  }catch(e){ console.error(e); }
}

async function refreshStats(){
  try{
    const res=await fetch('/api/stats?t='+Date.now());
    const d=await res.json();
    document.getElementById('fpsVal').textContent = d.fps;
    document.getElementById('ramVal').textContent = d.ram_mb;
    document.getElementById('cpuVal').textContent = d.cpu_percent;
  }catch(e){ console.error(e); }
}

function showToast(msg){
  const wrap=document.getElementById('toastWrap');
  const el=document.createElement('div');
  el.className='toast';
  el.textContent=msg;
  wrap.appendChild(el);
  setTimeout(()=>el.remove(),6000);
  playAlertBeep();
}

let audioCtx=null;
function playAlertBeep(){
  try{
    if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    const osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
    osc.type='sine'; osc.frequency.value=880;
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime+0.35);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(); osc.stop(audioCtx.currentTime+0.35);
  }catch(e){ /* autoplay may be blocked until the user interacts with the page once - harmless */ }
}

function setLogFilter(status,btn){
  logFilterStatus=status;
  document.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
  btn.classList.add('active');
  renderLog();
}

function renderLog(){
  const search=(document.getElementById('logSearch').value||'').toLowerCase();
  let rows=allLogRecords;
  if(logFilterStatus!=='all') rows=rows.filter(r=>r.Status===logFilterStatus);
  if(search) rows=rows.filter(r=>(r.Name||'').toLowerCase().includes(search));

  const cont=document.getElementById('logContainer');
  if(!rows.length){ cont.innerHTML='<p class="no-rec">No matching detections.</p>'; return; }
  cont.innerHTML = `<table><thead><tr><th>Name</th><th>Time</th><th>Camera</th><th>Status</th><th>Confidence</th></tr></thead>
    <tbody>${rows.map(r=>{
      const badge = r.Status==='Unknown' ? '<span class="badge unknown">UNKNOWN</span>' : '<span class="badge here">OK</span>';
      const conf = (r.Confidence!==undefined && r.Confidence!=='' && r.Confidence!=null) ? r.Confidence+'%' : '-';
      return `<tr><td>${r.Name}</td><td>${r.Time}</td><td>${r.Camera||''}</td><td>${badge}</td><td>${conf}</td></tr>`;
    }).join('')}</tbody></table>`;
}

function drawHourChart(){
  const canvas=document.getElementById('hourChart');
  const ctx=canvas.getContext('2d');
  const w=canvas.clientWidth||canvas.parentElement.clientWidth, h=90;
  canvas.width=w; canvas.height=h;
  ctx.clearRect(0,0,w,h);

  const counts=new Array(24).fill(0);
  allLogRecords.forEach(r=>{
    const hr=parseInt((r.Time||'00:00:00').split(':')[0],10);
    if(!isNaN(hr)) counts[hr]++;
  });
  const max=Math.max(1,...counts);
  const barW=w/24;
  ctx.fillStyle='#3b82f6';
  counts.forEach((c,i)=>{
    const barH=(c/max)*(h-16);
    ctx.fillRect(i*barW+1, h-barH-14, barW-2, barH);
  });
  ctx.fillStyle='#64748b';
  ctx.font='9px sans-serif';
  [0,6,12,18,23].forEach(i=>{ ctx.fillText(i+'h', i*barW, h-2); });
}

async function loadLog(){
  const date=document.getElementById('logDate').value;
  const res=await fetch('/api/log?date='+date+'&t='+Date.now());
  const d=await res.json();
  document.getElementById('todayCount').textContent = d.count;
  const known = d.records.filter(r=>r.Status==='Recognized').length;
  const unknown = d.records.filter(r=>r.Status==='Unknown').length;
  document.getElementById('kuRatio').textContent = known+' / '+unknown;
  allLogRecords = d.records;
  renderLog();
  drawHourChart();
}

function downloadCSV(){
  const date=document.getElementById('logDate').value;
  window.open('/api/export.csv?date='+date,'_blank');
}
function downloadPDF(){
  const date=document.getElementById('logDate').value;
  window.open('/api/report.pdf?date='+date,'_blank');
}

async function controlDetection(action){
  showCtrl('Working...','');
  try{
    const res=await fetch('/api/control/'+action,{method:'POST'});
    const d=await res.json();
    showCtrl(d.running?'Detection running.':'Detection stopped.','success');
    document.getElementById('camFeed').src='/video_feed?t='+Date.now();
  }catch(e){ showCtrl('Error: '+e,'error'); }
}

async function reloadFaces(){
  showCtrl('Reloading known faces...','');
  try{
    const res=await fetch('/api/reload_faces',{method:'POST'});
    const d=await res.json();
    showCtrl('Loaded '+d.count+' known face(s).','success');
  }catch(e){ showCtrl('Error: '+e,'error'); }
}

async function runDiagnostics(){
  const box=document.getElementById('diagResults');
  box.innerHTML='<p class="no-rec">Running - this checks several settings, may take a few seconds...</p>';
  try{
    const res=await fetch('/api/diagnostics',{method:'POST'});
    const d=await res.json();
    if(d.error){ box.innerHTML='<p class="no-rec">'+d.error+'</p>'; return; }

    const rows = d.results.map(r=>{
      if(r.error) return `<tr><td>${r.label}</td><td colspan="2" style="color:#f87171">${r.error}</td></tr>`;
      const color = r.faces_found>0 ? '#4ade80' : '#f87171';
      return `<tr><td>${r.label}</td><td style="color:${color};font-weight:700">${r.faces_found}</td><td>${r.seconds}s</td></tr>`;
    }).join('');

    let verdict;
    if(d.best_faces_found>0){
      verdict = `<p style="color:#4ade80;font-size:.8rem;margin-bottom:8px">Found ${d.best_faces_found} face(s) with at least one setting - your current config may just need those values. See the annotated image below.</p>`;
    } else {
      verdict = `<p style="color:#f87171;font-size:.8rem;margin-bottom:8px">No faces found at ANY setting, including full resolution with heavy upsampling. This means the faces in this frame aren't detectable as faces right now - most likely they're turned away, angled down, or too small/blurry even at full size. Check the raw image below: if you can't easily tell it's a face yourself at a glance, the detector won't either. This points to camera angle/placement, not a config value.</p>`;
    }

    const raw = `<div style="margin-bottom:8px"><div style="font-size:.72rem;color:#64748b;margin-bottom:4px">Raw frame tested (${d.frame_size}):</div><img src="/debug_image/${d.raw_image}?t=${Date.now()}" style="width:100%;border-radius:8px"/></div>`;
    const annotated = d.annotated_image
      ? `<div style="margin-bottom:8px"><div style="font-size:.72rem;color:#64748b;margin-bottom:4px">Best result annotated:</div><img src="/debug_image/${d.annotated_image}?t=${Date.now()}" style="width:100%;border-radius:8px"/></div>`
      : '';

    box.innerHTML = verdict + raw + annotated +
      `<table><thead><tr><th>Setting</th><th>Faces</th><th>Time</th></tr></thead><tbody>${rows}</tbody></table>`;
  }catch(e){
    box.innerHTML='<p class="no-rec">Error: '+e+'</p>';
  }
}

function showCtrl(t,cls){
  const el=document.getElementById('ctrlMsg');
  el.textContent=t; el.className='msg '+cls;
  setTimeout(()=>{el.textContent='';},4000);
}

function closeModal(id){ document.getElementById(id).classList.remove('show'); }

async function openSettings(){
  const res=await fetch('/api/settings');
  const cfg=await res.json();
  document.getElementById('s_camera_name').value = cfg.camera.name || '';
  document.getElementById('s_camera_source').value = cfg.camera.source || '';
  document.getElementById('s_tolerance').value = cfg.detection.tolerance ?? 0.5;
  document.getElementById('s_cooldown').value = cfg.detection.cooldown_seconds ?? 60;
  document.getElementById('s_presence').value = cfg.detection.presence_timeout_seconds ?? 20;
  document.getElementById('s_everyn').value = cfg.detection.process_every_n_frames ?? 3;
  document.getElementById('s_scale').value = cfg.detection.scale_factor ?? 0.5;
  document.getElementById('s_upsample').value = cfg.detection.upsample ?? 1;
  document.getElementById('s_model').value = cfg.detection.model ?? 'hog';
  document.getElementById('s_logunknown').value = String(cfg.detection.log_unknown ?? true);
  document.getElementById('s_retention').value = cfg.detection.retention_days ?? 0;
  document.getElementById('settingsModal').classList.add('show');
}

async function saveSettings(){
  const payload = {
    camera: { name: document.getElementById('s_camera_name').value, source: document.getElementById('s_camera_source').value },
    detection: {
      tolerance: parseFloat(document.getElementById('s_tolerance').value),
      cooldown_seconds: parseInt(document.getElementById('s_cooldown').value),
      presence_timeout_seconds: parseInt(document.getElementById('s_presence').value),
      process_every_n_frames: parseInt(document.getElementById('s_everyn').value),
      scale_factor: parseFloat(document.getElementById('s_scale').value),
      upsample: parseInt(document.getElementById('s_upsample').value),
      model: document.getElementById('s_model').value,
      log_unknown: document.getElementById('s_logunknown').value === 'true',
      retention_days: parseInt(document.getElementById('s_retention').value || '0')
    }
  };
  try{
    const res=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    await res.json();
    document.getElementById('settingsMsg').textContent='Saved.';
    document.getElementById('settingsMsg').className='msg success';
    document.getElementById('camNameVal').textContent = payload.camera.name;
    setTimeout(()=>closeModal('settingsModal'),900);
  }catch(e){
    document.getElementById('settingsMsg').textContent='Error: '+e;
    document.getElementById('settingsMsg').className='msg error';
  }
}

function openRegister(){
  document.getElementById('r_name').value='';
  document.getElementById('r_file').value='';
  document.getElementById('previewImg').style.display='none';
  document.getElementById('registerMsg').textContent='';
  document.getElementById('registerModal').classList.add('show');
}
function previewPhoto(input){
  const file=input.files[0]; if(!file)return;
  const r=new FileReader();
  r.onload=e=>{ const img=document.getElementById('previewImg'); img.src=e.target.result; img.style.display='block'; };
  r.readAsDataURL(file);
}
async function submitRegister(){
  const name=document.getElementById('r_name').value.trim();
  const file=document.getElementById('r_file').files[0];
  const msg=document.getElementById('registerMsg');
  if(!name){ msg.textContent='Enter a name.'; msg.className='msg error'; return; }
  if(!file){ msg.textContent='Choose a photo.'; msg.className='msg error'; return; }
  const reader=new FileReader();
  reader.onload=async (e)=>{
    msg.textContent='Registering...'; msg.className='msg';
    try{
      const res=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({name,image:e.target.result})});
      const d=await res.json();
      if(d.ok){ msg.textContent=d.message; msg.className='msg success'; setTimeout(()=>closeModal('registerModal'),1200); }
      else { msg.textContent=d.error; msg.className='msg error'; }
    }catch(err){ msg.textContent='Error: '+err; msg.className='msg error'; }
  };
  reader.readAsDataURL(file);
}

async function openPersonDetail(name){
  document.getElementById('pd_name').textContent=name;
  document.getElementById('pd_history').innerHTML='<p class="no-rec">Loading...</p>';
  document.getElementById('personModal').classList.add('show');
  try{
    const res=await fetch('/api/person/'+encodeURIComponent(name));
    const d=await res.json();
    const live=d.live;
    document.getElementById('pd_thumb').src = live && live.thumbnail ? live.thumbnail : '';
    document.getElementById('pd_status').textContent = live ? live.status : '-';
    document.getElementById('pd_conf').textContent = live && live.confidence!=null ? live.confidence+'%' : '-';
    document.getElementById('pd_arrived').textContent = live ? live.first_seen : '-';
    document.getElementById('pd_left').textContent = live ? (live.left_at || live.last_seen+' (still here)') : '-';
    const kindBadge = live && live.kind==='Unknown' ? '<span class="badge unknown">UNKNOWN</span>' : '<span class="badge here">RECOGNIZED</span>';
    document.getElementById('pd_badges').innerHTML = kindBadge;

    const hist=document.getElementById('pd_history');
    if(!d.history.length){ hist.innerHTML='<p class="no-rec">No historical sightings logged.</p>'; return; }
    hist.innerHTML = `<table><thead><tr><th>Date</th><th>Time</th><th>Camera</th><th>Status</th><th>Confidence</th></tr></thead>
      <tbody>${d.history.map(r=>{
        const conf=(r.Confidence!==undefined && r.Confidence!=='' && r.Confidence!=null) ? r.Confidence+'%' : '-';
        return `<tr><td>${r.Date}</td><td>${r.Time}</td><td>${r.Camera||''}</td><td>${r.Status}</td><td>${conf}</td></tr>`;
      }).join('')}</tbody></table>`;
  }catch(e){
    document.getElementById('pd_history').innerHTML='<p class="no-rec">Error loading history.</p>';
  }
}

let savedCameras=[];
async function openCameraSwitch(){
  document.getElementById('cameraMsg').textContent='';
  try{
    const res=await fetch('/api/cameras');
    const d=await res.json();
    savedCameras=d.saved||[];
    const sel=document.getElementById('cam_saved');
    const group=document.getElementById('cam_saved_group');
    if(savedCameras.length){
      group.style.display='block';
      sel.innerHTML='<option value="">-- choose a saved camera --</option>'+
        savedCameras.map((c,i)=>`<option value="${i}">${c.name}</option>`).join('');
    } else {
      group.style.display='none';
    }
    document.getElementById('cam_name').value = d.active.name || '';
    document.getElementById('cam_source').value = d.active.source || '';
  }catch(e){}
  document.getElementById('cameraModal').classList.add('show');
}
function fillCameraForm(){
  const idx=document.getElementById('cam_saved').value;
  if(idx==='') return;
  const cam=savedCameras[parseInt(idx)];
  document.getElementById('cam_name').value=cam.name;
  document.getElementById('cam_source').value=cam.source;
}
async function submitCameraSwitch(){
  const name=document.getElementById('cam_name').value.trim();
  const source=document.getElementById('cam_source').value.trim();
  const save=document.getElementById('cam_save').checked;
  const msg=document.getElementById('cameraMsg');
  if(!name || !source){ msg.textContent='Name and source are required.'; msg.className='msg error'; return; }
  msg.textContent='Switching...'; msg.className='msg';
  try{
    const res=await fetch('/api/cameras/switch',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name,source,save})});
    const d=await res.json();
    if(d.ok){
      msg.textContent='Switched to '+name; msg.className='msg success';
      document.getElementById('cameraLabel').textContent='Live Camera Feed - '+name;
      document.getElementById('camNameVal').textContent=name;
      document.getElementById('camFeed').src='/video_feed?t='+Date.now();
      setTimeout(()=>closeModal('cameraModal'),1000);
    } else {
      msg.textContent=d.error||'Failed to switch.'; msg.className='msg error';
    }
  }catch(e){ msg.textContent='Error: '+e; msg.className='msg error'; }
}

document.querySelectorAll('.modal-bg').forEach(m=>{
  m.addEventListener('click',e=>{ if(e.target===m) m.classList.remove('show'); });
});

window.addEventListener('resize', drawHourChart);

loadLog();
refreshPresence(); setInterval(refreshPresence,2000);
refreshStats(); setInterval(refreshStats,4000);
setInterval(loadLog, 60000);
</script>
</body>
</html>
"""


@app.route("/")
def index():
    return render_template_string(HTML)


if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  AI Face Detection - Web Dashboard")
    print("  Open: http://localhost:5000")
    print("=" * 50 + "\n")
    engine.start()
    app.run(debug=False, host="0.0.0.0", port=5000, threaded=True)
