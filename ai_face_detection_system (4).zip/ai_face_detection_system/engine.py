"""
engine.py
=========
The detection engine behind the web dashboard (app.py).

Runs the camera + face-recognition loop in a background thread and keeps
these updated for the UI to read at any moment:

  1. The latest annotated video frame (JPEG bytes), for the live preview.
  2. A "presence" table: for every person currently or recently seen,
     when they FIRST appeared, when they were LAST seen, whether they're
     still "IN" frame or have "left", a match confidence estimate, and a
     small face thumbnail.
  3. Rough performance stats (processing FPS) for the dashboard's status
     footer.

detector.py (the CLI version) is separate and doesn't use this file - this
one exists specifically to power the web dashboard.
"""

import os
import json
import time
import base64
import threading
from collections import deque
from datetime import datetime

import cv2
import numpy as np
import face_recognition

from utils.face_loader import load_known_faces
from utils.camera_stream import CameraStream
from utils.logger import log_detection, purge_old_logs

CONFIG_PATH = "config.json"


def load_config() -> dict:
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


def _confidence_from_distance(distance: float) -> float:
    """
    Rough match-confidence estimate from a face_distance() score.
    This is NOT a calibrated probability - face_recognition doesn't
    provide one - just a friendlier 0-100 read on "how close was the
    match" for display purposes. Lower distance = higher confidence.
    """
    return max(0.0, min(1.0, 1.0 - distance)) * 100.0


class DetectionEngine:
    def __init__(self, config_path: str = CONFIG_PATH):
        self.config_path = config_path
        self.cfg = load_config()

        self._frame_lock = threading.Lock()
        self._presence_lock = threading.Lock()

        self.running = False
        self.thread = None
        self.stream = None
        self.connected = False

        self.known_encodings = []
        self.known_names = []

        self._latest_jpeg = None
        self._latest_raw_frame = None  # unannotated, for diagnostics
        self._last_face_count = 0

        # name -> {name, kind, status ("IN"/"OUT"), first_seen, last_seen,
        #          left_at, confidence, thumbnail (base64 data URI)}
        self.presence = {}

        # rolling window of frame-processing timestamps, for an FPS estimate
        self._proc_times = deque(maxlen=30)
        self.fps = 0.0

    # ---------------- lifecycle ----------------

    def reload_config(self):
        self.cfg = load_config()

    def reload_faces(self) -> int:
        path_cfg = self.cfg["paths"]
        encs, names = load_known_faces(path_cfg["known_faces_dir"])
        self.known_encodings = encs
        self.known_names = names
        return len(names)

    def start(self):
        if self.running:
            return
        self.cfg = load_config()
        self.reload_faces()

        retention = self.cfg.get("detection", {}).get("retention_days", 0)
        try:
            purge_old_logs(retention)
        except Exception as e:
            print(f"[WARN] Log retention purge failed: {e}")

        cam_cfg = self.cfg["camera"]
        self.stream = CameraStream(
            source=cam_cfg["source"],
            reconnect_delay=cam_cfg.get("reconnect_delay_seconds", 5),
            name=cam_cfg.get("name", "Camera"),
        ).start()

        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=3)
        if self.stream is not None:
            self.stream.stop()
            self.stream = None
        with self._frame_lock:
            self._latest_jpeg = None

    def is_running(self) -> bool:
        return self.running

    def switch_camera(self, name: str, source) -> None:
        """Stop (if running), point at a new camera source, and restart if it was running."""
        was_running = self.running
        if was_running:
            self.stop()

        cfg = load_config()
        cfg["camera"]["name"] = name
        cfg["camera"]["source"] = source
        save_config(cfg)
        self.cfg = cfg

        with self._presence_lock:
            self.presence = {}

        if was_running:
            self.start()

    # ---------------- read access for the web layer ----------------

    def get_jpeg(self):
        with self._frame_lock:
            return self._latest_jpeg

    def get_presence_snapshot(self) -> dict:
        with self._presence_lock:
            return {k: dict(v) for k, v in self.presence.items()}

    def get_stats(self) -> dict:
        return {
            "fps": round(self.fps, 1),
            "known_count": len(self.known_names),
            "connected": bool(self.connected),
            "running": self.running,
            "last_face_count": self._last_face_count,
        }

    def get_raw_frame(self):
        with self._frame_lock:
            return None if self._latest_raw_frame is None else self._latest_raw_frame.copy()

    def run_diagnostics(self) -> dict:
        """
        Run face detection on the CURRENT raw frame at several different
        settings (full resolution vs. the configured scale, upsample 0/1/2,
        hog vs cnn) so we can see exactly why nothing is being found,
        instead of guessing at config numbers. Saves an annotated debug
        image for each combo to detection_logs/debug/.

        Returns a dict of results, or {"error": "..."} if there's no frame
        to test yet (camera not connected / detection not running).
        """
        frame = self.get_raw_frame()
        if frame is None:
            return {"error": "No frame available yet. Make sure detection is running "
                              "and the camera is connected, then try again."}

        debug_dir = os.path.join("detection_logs", "debug")
        os.makedirs(debug_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        fh, fw = frame.shape[:2]
        configured_scale = self.cfg.get("detection", {}).get("scale_factor", 0.5)

        combos = [
            {"label": "full-res, upsample=0, hog", "scale": 1.0, "upsample": 0, "model": "hog"},
            {"label": "full-res, upsample=1, hog", "scale": 1.0, "upsample": 1, "model": "hog"},
            {"label": "full-res, upsample=2, hog", "scale": 1.0, "upsample": 2, "model": "hog"},
            {"label": f"configured scale ({configured_scale}), upsample=1, hog",
             "scale": configured_scale, "upsample": 1, "model": "hog"},
        ]

        results = []
        best_combo = None
        best_count = -1

        for combo in combos:
            try:
                small = cv2.resize(frame, (0, 0), fx=combo["scale"], fy=combo["scale"]) \
                    if combo["scale"] != 1.0 else frame
                rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                start = time.time()
                locations = face_recognition.face_locations(
                    rgb, number_of_times_to_upsample=combo["upsample"], model=combo["model"]
                )
                elapsed = time.time() - start
                results.append({
                    "label": combo["label"],
                    "faces_found": len(locations),
                    "seconds": round(elapsed, 2),
                })
                if len(locations) > best_count:
                    best_count = len(locations)
                    best_combo = (combo, locations, small.copy())
            except Exception as e:
                results.append({"label": combo["label"], "error": str(e)})

        # try cnn once too, separately, since it can be unavailable/very slow
        try:
            start = time.time()
            rgb_full = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            cnn_locations = face_recognition.face_locations(
                rgb_full, number_of_times_to_upsample=0, model="cnn"
            )
            elapsed = time.time() - start
            results.append({
                "label": "full-res, upsample=0, cnn",
                "faces_found": len(cnn_locations),
                "seconds": round(elapsed, 2),
            })
            if len(cnn_locations) > best_count:
                best_count = len(cnn_locations)
                best_combo = ({"label": "full-res, upsample=0, cnn", "scale": 1.0}, cnn_locations, frame.copy())
        except Exception as e:
            results.append({"label": "full-res, upsample=0, cnn", "error": f"unavailable: {e}"})

        # save the raw frame (so you can see exactly what the camera sees)
        raw_path = os.path.join(debug_dir, f"raw_{ts}.jpg")
        cv2.imwrite(raw_path, frame)

        # save an annotated frame using whichever combo found the most faces
        annotated_path = None
        if best_combo and best_count > 0:
            combo, locations, used_frame = best_combo
            scale_back = 1.0 / combo.get("scale", 1.0)
            annotated = frame.copy()
            for (top, right, bottom, left) in locations:
                top, right, bottom, left = [int(v * scale_back) for v in (top, right, bottom, left)]
                cv2.rectangle(annotated, (left, top), (right, bottom), (0, 200, 0), 3)
            annotated_path = os.path.join(debug_dir, f"annotated_{ts}.jpg")
            cv2.imwrite(annotated_path, annotated)

        return {
            "frame_size": f"{fw}x{fh}",
            "results": results,
            "best_faces_found": max(best_count, 0),
            "raw_image": os.path.basename(raw_path),
            "annotated_image": os.path.basename(annotated_path) if annotated_path else None,
        }

    # ---------------- main loop ----------------

    def _loop(self):
        det_cfg = self.cfg["detection"]
        tolerance = det_cfg.get("tolerance", 0.5)
        scale = det_cfg.get("scale_factor", 0.5)
        every_n = max(1, det_cfg.get("process_every_n_frames", 3))
        cooldown = det_cfg.get("cooldown_seconds", 60)
        log_unknown = det_cfg.get("log_unknown", True)
        presence_timeout = det_cfg.get("presence_timeout_seconds", 20)
        upsample = det_cfg.get("upsample", 1)
        model = det_cfg.get("model", "hog")
        roi = det_cfg.get("roi")  # [x1,y1,x2,y2] as 0..1 fractions of the frame, or null
        camera_name = self.cfg["camera"].get("name", "Camera")

        last_logged = {}
        last_boxes = []
        frame_count = 0

        while self.running:
            frame = self.stream.read() if self.stream else None
            self.connected = self.stream.is_connected() if self.stream else False

            if frame is None:
                self._check_departures(presence_timeout)
                time.sleep(0.03)
                continue

            frame_count += 1
            run_this_frame = (frame_count % every_n == 0)

            with self._frame_lock:
                self._latest_raw_frame = frame.copy()

            if run_this_frame:
                self._proc_times.append(time.time())
                if len(self._proc_times) >= 2:
                    span = self._proc_times[-1] - self._proc_times[0]
                    self.fps = (len(self._proc_times) - 1) / span if span > 0 else 0.0

                fh, fw = frame.shape[:2]
                if roi and len(roi) == 4:
                    rx1, ry1, rx2, ry2 = [int(v * fw) if i % 2 == 0 else int(v * fh)
                                           for i, v in enumerate(roi)]
                    roi_frame = frame[ry1:ry2, rx1:rx2]
                    offset_x, offset_y = rx1, ry1
                else:
                    roi_frame = frame
                    offset_x, offset_y = 0, 0

                small = cv2.resize(roi_frame, (0, 0), fx=scale, fy=scale)
                rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                face_locations = face_recognition.face_locations(
                    rgb_small, number_of_times_to_upsample=upsample, model=model
                )
                face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

                last_boxes = []
                now_ts = time.time()

                for enc, loc in zip(face_encodings, face_locations):
                    name = "Unknown"
                    color = (0, 0, 220)
                    kind = "Unknown"
                    confidence = None

                    if self.known_encodings:
                        distances = face_recognition.face_distance(self.known_encodings, enc)
                        best_idx = int(np.argmin(distances))
                        best_distance = distances[best_idx]
                        if best_distance <= tolerance:
                            name = self.known_names[best_idx]
                            color = (0, 200, 0)
                            kind = "Recognized"
                            confidence = _confidence_from_distance(best_distance)

                    scale_back = int(round(1 / scale))
                    top, right, bottom, left = [v * scale_back for v in loc]
                    top, bottom = top + offset_y, bottom + offset_y
                    left, right = left + offset_x, right + offset_x
                    label = f"{name} {confidence:.0f}%" if confidence is not None else name
                    last_boxes.append((label, color, (top, right, bottom, left)))

                    if kind == "Unknown" and not log_unknown:
                        continue

                    thumb_bytes = self._make_thumbnail_bytes(frame, (top, right, bottom, left))
                    thumb_b64 = self._bytes_to_data_uri(thumb_bytes)
                    self._update_presence(name, kind, now_ts, thumb_b64, confidence)

                    prior = last_logged.get(name, 0)
                    if now_ts - prior >= cooldown:
                        log_detection(name, camera_name, kind, confidence=confidence,
                                      snapshot_bytes=thumb_bytes)
                        last_logged[name] = now_ts

                self._last_face_count = len(last_boxes)

            self._draw_overlay(frame, last_boxes, camera_name)

            ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            if ok:
                with self._frame_lock:
                    self._latest_jpeg = buf.tobytes()

            self._check_departures(presence_timeout)

    def _draw_overlay(self, frame, boxes, camera_name):
        for label, color, (top, right, bottom, left) in boxes:
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.rectangle(frame, (left, bottom - 34), (right, bottom), color, cv2.FILLED)
            cv2.putText(frame, label, (left + 6, bottom - 8),
                        cv2.FONT_HERSHEY_DUPLEX, 0.65, (255, 255, 255), 1)

        status_color = (0, 220, 255) if self.connected else (0, 0, 220)
        cv2.putText(frame, datetime.now().strftime("%Y-%m-%d  %H:%M:%S"), (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
        cv2.putText(frame, camera_name, (10, 56),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, status_color, 1)
        cv2.putText(frame, f"Faces this frame: {len(boxes)}", (10, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 0), 1)

    def _make_thumbnail_bytes(self, frame, box, size: int = 128):
        top, right, bottom, left = box
        h, w = frame.shape[:2]
        top, left = max(0, top), max(0, left)
        bottom, right = min(h, bottom), min(w, right)
        if bottom <= top or right <= left:
            return None
        try:
            crop = cv2.resize(frame[top:bottom, left:right], (size, size))
            ok, buf = cv2.imencode(".jpg", crop)
            return buf.tobytes() if ok else None
        except Exception:
            return None

    @staticmethod
    def _bytes_to_data_uri(jpeg_bytes):
        if not jpeg_bytes:
            return None
        return "data:image/jpeg;base64," + base64.b64encode(jpeg_bytes).decode("ascii")

    def _update_presence(self, name, kind, now_ts, thumb_b64, confidence):
        with self._presence_lock:
            entry = self.presence.get(name)
            if entry is None or entry.get("status") == "OUT":
                self.presence[name] = {
                    "name": name,
                    "kind": kind,
                    "status": "IN",
                    "first_seen": now_ts,
                    "last_seen": now_ts,
                    "left_at": None,
                    "confidence": confidence,
                    "thumbnail": thumb_b64 or (entry.get("thumbnail") if entry else None),
                }
            else:
                entry["last_seen"] = now_ts
                if confidence is not None:
                    entry["confidence"] = confidence
                if thumb_b64:
                    entry["thumbnail"] = thumb_b64

    def _check_departures(self, presence_timeout):
        now_ts = time.time()
        with self._presence_lock:
            for entry in self.presence.values():
                if entry["status"] == "IN" and now_ts - entry["last_seen"] > presence_timeout:
                    entry["status"] = "OUT"
                    entry["left_at"] = entry["last_seen"]
