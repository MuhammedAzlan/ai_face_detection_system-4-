"""
utils/logger.py
================
Logs every detection EVENT (not just "present today") to a daily CSV, and
optionally archives a cropped face snapshot alongside it.

Columns: Name, Date, Time, Camera, Status, Confidence, Snapshot
    Status      : "Recognized" or "Unknown"
    Confidence  : approximate match confidence 0-100 (blank for Unknown)
    Snapshot    : relative path to the archived face crop, or blank
"""

import pandas as pd
import os
from datetime import datetime, timedelta

LOGS_DIR = "detection_logs"
SNAPSHOTS_SUBDIR = "snapshots"


def get_today_log() -> str:
    """Return the filepath for today's detection log CSV."""
    today = datetime.now().strftime("%Y-%m-%d")
    return os.path.join(LOGS_DIR, f"{today}.csv")


def log_detection(name: str, camera_name: str, status: str = "Recognized",
                   confidence=None, snapshot_bytes: bytes = None) -> str:
    """
    Append one detection event to today's CSV, optionally archiving a
    snapshot image alongside it.

    Args:
        name            : Person's display name, or "Unknown".
        camera_name     : Which camera/channel saw them.
        status          : "Recognized" or "Unknown".
        confidence      : Approximate match confidence, 0-100 (or None).
        snapshot_bytes  : Raw JPEG bytes of the cropped face, or None to skip archiving.

    Returns:
        The relative snapshot path that was saved (or "" if none was saved).
    """
    os.makedirs(LOGS_DIR, exist_ok=True)
    log_file = get_today_log()

    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")

    snapshot_rel = ""
    if snapshot_bytes:
        day_dir = os.path.join(LOGS_DIR, SNAPSHOTS_SUBDIR, date_str)
        os.makedirs(day_dir, exist_ok=True)
        safe_name = "".join(c if c.isalnum() else "_" for c in name)
        fname = f"{safe_name}_{now.strftime('%H%M%S_%f')}.jpg"
        with open(os.path.join(day_dir, fname), "wb") as f:
            f.write(snapshot_bytes)
        snapshot_rel = os.path.join(SNAPSHOTS_SUBDIR, date_str, fname)

    row = {
        "Name": name,
        "Date": date_str,
        "Time": time_str,
        "Camera": camera_name,
        "Status": status,
        "Confidence": round(confidence, 1) if confidence is not None else "",
        "Snapshot": snapshot_rel,
    }

    if not os.path.exists(log_file):
        pd.DataFrame(columns=list(row.keys())).to_csv(log_file, index=False)

    df = pd.read_csv(log_file)
    # older logs may be missing newer columns - add them so concat doesn't break
    for col in row.keys():
        if col not in df.columns:
            df[col] = ""
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    df.to_csv(log_file, index=False)

    conf_str = f" ({row['Confidence']}%)" if row["Confidence"] != "" else ""
    print(f"[DETECTED] {name}{conf_str}  ({status})  |  {time_str}  |  {camera_name}")
    return snapshot_rel


def view_today_log() -> None:
    """Print today's detection log to console."""
    log_file = get_today_log()

    if not os.path.exists(log_file):
        print("[INFO] No detections logged today yet.")
        return

    df = pd.read_csv(log_file)

    if df.empty:
        print("[INFO] No detections logged today yet.")
    else:
        print(f"\n{'-'*60}")
        print(f"  Detection Log — {datetime.now().strftime('%Y-%m-%d')}")
        print(f"{'-'*60}")
        cols = [c for c in ["Name", "Time", "Camera", "Status", "Confidence"] if c in df.columns]
        print(df[cols].to_string(index=False))
        print(f"{'-'*60}")
        print(f"  Total events: {len(df)}")
        print(f"{'-'*60}\n")


def export_all_logs(output_path: str = "full_report.csv") -> None:
    """Merge every daily CSV in detection_logs/ into one combined file."""
    if not os.path.exists(LOGS_DIR):
        print("[WARN] No logs directory found.")
        return

    files = sorted(
        os.path.join(LOGS_DIR, f) for f in os.listdir(LOGS_DIR) if f.endswith(".csv")
    )

    if not files:
        print("[WARN] No log files found.")
        return

    all_dfs = [pd.read_csv(f) for f in files if os.path.getsize(f) > 0]
    merged = pd.concat(all_dfs, ignore_index=True)
    merged.to_csv(output_path, index=False)
    print(f"[OK] Full report exported: {output_path} ({len(merged)} events)")


def get_person_history(name: str, limit: int = 50) -> pd.DataFrame:
    """Every logged sighting of one person, across all daily CSVs, most recent first."""
    if not os.path.exists(LOGS_DIR):
        return pd.DataFrame()
    files = sorted((f for f in os.listdir(LOGS_DIR) if f.endswith(".csv")), reverse=True)
    rows = []
    for file in files:
        df = pd.read_csv(os.path.join(LOGS_DIR, file))
        if df.empty or "Name" not in df.columns:
            continue
        match = df[df["Name"].astype(str).str.lower() == name.lower()]
        if not match.empty:
            rows.append(match)
        if sum(len(r) for r in rows) >= limit:
            break
    if not rows:
        return pd.DataFrame()
    combined = pd.concat(rows, ignore_index=True)
    return combined.iloc[:limit]


def purge_old_logs(retention_days: int) -> int:
    """
    Delete daily CSV logs (and their snapshot folders) older than
    retention_days. retention_days <= 0 disables purging. Returns the
    number of days' worth of data removed.
    """
    if not retention_days or retention_days <= 0:
        return 0
    if not os.path.exists(LOGS_DIR):
        return 0

    cutoff = datetime.now() - timedelta(days=retention_days)
    removed = 0
    for f in os.listdir(LOGS_DIR):
        if not f.endswith(".csv"):
            continue
        date_str = f.replace(".csv", "")
        try:
            file_date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            continue
        if file_date < cutoff:
            os.remove(os.path.join(LOGS_DIR, f))
            snap_dir = os.path.join(LOGS_DIR, SNAPSHOTS_SUBDIR, date_str)
            if os.path.isdir(snap_dir):
                import shutil
                shutil.rmtree(snap_dir, ignore_errors=True)
            removed += 1
    if removed:
        print(f"[OK] Purged {removed} day(s) of logs older than {retention_days} days.")
    return removed
