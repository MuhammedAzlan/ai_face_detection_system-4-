"""
report.py
=========
Generates a daily PDF summary report: total detections, known vs.
unknown counts, an hourly activity breakdown, and a table of every
detection event (with a thumbnail where one was archived).

Used by app.py's /api/report.pdf endpoint.
"""

import os
from datetime import datetime
from io import BytesIO

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

from utils.logger import LOGS_DIR

PAGE_MARGIN = 16 * mm


def _load_day(date_str: str) -> pd.DataFrame:
    path = os.path.join(LOGS_DIR, f"{date_str}.csv")
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path)


def generate_daily_report_pdf(date_str: str, camera_name: str = "") -> bytes:
    df = _load_day(date_str)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleX", parent=styles["Title"], fontSize=18)
    small = ParagraphStyle("Small", parent=styles["Normal"], fontSize=9, textColor=colors.grey)

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=PAGE_MARGIN, rightMargin=PAGE_MARGIN,
        topMargin=PAGE_MARGIN, bottomMargin=PAGE_MARGIN,
    )

    story = []
    story.append(Paragraph("AI Face Detection - Daily Report", title_style))
    story.append(Paragraph(
        f"Date: {date_str}" + (f" &nbsp;&nbsp; Camera: {camera_name}" if camera_name else ""),
        styles["Normal"]
    ))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", small
    ))
    story.append(Spacer(1, 10 * mm))

    if df.empty:
        story.append(Paragraph("No detections were logged for this date.", styles["Normal"]))
        doc.build(story)
        return buf.getvalue()

    total = len(df)
    recognized = int((df["Status"] == "Recognized").sum()) if "Status" in df.columns else 0
    unknown = int((df["Status"] == "Unknown").sum()) if "Status" in df.columns else 0
    unique_people = df[df["Status"] == "Recognized"]["Name"].nunique() if "Status" in df.columns else 0

    # ---- summary stat table ----
    summary_data = [
        ["Total Detections", "Recognized", "Unknown", "Unique People"],
        [str(total), str(recognized), str(unknown), str(unique_people)],
    ]
    summary_table = Table(summary_data, colWidths=[40 * mm] * 4)
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 1), (-1, 1), 14),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 8 * mm))

    # ---- hourly activity breakdown ----
    if "Time" in df.columns:
        hours = df["Time"].astype(str).str.slice(0, 2)
        hour_counts = hours.value_counts().sort_index()
        if len(hour_counts):
            story.append(Paragraph("Detections by Hour", styles["Heading3"]))
            hour_rows = [["Hour", "Detections"]]
            for h, c in hour_counts.items():
                hour_rows.append([f"{h}:00", str(c)])
            hour_table = Table(hour_rows, colWidths=[30 * mm, 30 * mm])
            hour_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#334155")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e2e8f0")),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ]))
            story.append(hour_table)
            story.append(Spacer(1, 8 * mm))

    # ---- detail table with thumbnails ----
    story.append(Paragraph("Detection Log", styles["Heading3"]))
    header = ["Photo", "Name", "Time", "Camera", "Status", "Confidence"]
    rows = [header]

    for _, r in df.iterrows():
        photo_cell = ""
        snap_path = str(r.get("Snapshot", "") or "")
        resolved = os.path.join(LOGS_DIR, snap_path) if snap_path and snap_path != "nan" else ""
        if resolved and os.path.exists(resolved):
            try:
                photo_cell = Image(resolved, width=10 * mm, height=10 * mm)
            except Exception:
                photo_cell = ""

        conf = r.get("Confidence", "")
        conf_str = f"{conf}%" if conf not in ("", None) and not pd.isna(conf) else "-"

        rows.append([
            photo_cell,
            str(r.get("Name", "")),
            str(r.get("Time", "")),
            str(r.get("Camera", "")),
            str(r.get("Status", "")),
            conf_str,
        ])

    detail_table = Table(rows, colWidths=[14 * mm, 32 * mm, 22 * mm, 34 * mm, 24 * mm, 22 * mm], repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e2e8f0")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (2, 1), (-1, -1), "CENTER"),
    ]
    for i, r in df.iterrows():
        if str(r.get("Status", "")) == "Unknown":
            style_cmds.append(("BACKGROUND", (0, i + 1), (-1, i + 1), colors.HexColor("#fef2f2")))
    detail_table.setStyle(TableStyle(style_cmds))
    story.append(detail_table)

    doc.build(story)
    return buf.getvalue()
