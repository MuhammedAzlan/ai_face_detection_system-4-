@echo off
cd /d "%~dp0"

if not exist web.pid (
    echo [INFO] No web.pid found - the dashboard doesn't look like it's running
    echo        ^(or was started outside of start_web.bat^).
    pause
    exit /b 0
)

set /p PID=<web.pid
echo Stopping AI Face Detection Web Dashboard (PID %PID%)...

taskkill /PID %PID% /F >nul 2>&1
if %errorlevel%==0 (
    echo [OK] Stopped.
) else (
    echo [WARN] Process %PID% wasn't found - it may have already stopped.
)

del web.pid >nul 2>&1
echo.
pause
