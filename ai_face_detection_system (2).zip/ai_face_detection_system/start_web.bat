@echo off
cd /d "%~dp0"

if exist web.pid (
    echo [WARN] web.pid already exists - the dashboard may already be running.
    echo        Run stop_web.bat first, or open http://localhost:5000
    pause
    exit /b 1
)

echo Starting AI Face Detection Web Dashboard...
powershell -NoProfile -Command ^
  "$p = Start-Process -FilePath 'python' -ArgumentList 'app.py' -WindowStyle Minimized -PassThru; $p.Id | Out-File -Encoding ascii 'web.pid'"

timeout /t 2 /nobreak >nul

if exist web.pid (
    set /p PID=<web.pid
    echo [OK] Started. PID: %PID%
    echo      Open your browser to: http://localhost:5000
    start "" http://localhost:5000
) else (
    echo [ERROR] Failed to start. Check that Python and Flask are installed.
)
echo.
pause
