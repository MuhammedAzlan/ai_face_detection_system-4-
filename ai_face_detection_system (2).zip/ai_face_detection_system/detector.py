"""
AI Face Detection System — NVR / IP Camera Edition
====================================================
Watches a live RTSP feed from an IP camera or NVR channel. Whenever a
person moves in front of the camera, it detects their face, checks it
against known_faces/, and logs the event (name + exact time) to a
daily CSV in detection_logs/.

Unlike a plain "attendance" system, this does NOT stop after logging
someone once for the day — every appearance is logged (after a short
cooldown per person, so one 10-second walk-past doesn't create 100
rows). Configure everything in config.json — no code editing needed.

Run:
    python detector.py

Controls (only when display.show_window is true in config.json):
    Q  = quit
    R  = reload known faces (after adding new photos to known_faces/)
"""

import json
import time
import cv2
import numpy as np
import face_recognition

from utils.face_loader import load_known_faces
from utils.camera_stream import CameraStream
from utils.logger import log_detection

CONFIG_PATH = "config.json"


def load_config() -> dict:
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def run_detection():
    cfg = load_config()

    cam_cfg = cfg["camera"]
    det_cfg = cfg["detection"]
    path_cfg = cfg["paths"]
    disp_cfg = cfg.get("display", {"show_window": True})

    camera_name = cam_cfg.get("name", "Camera")
    tolerance = det_cfg.get("tolerance", 0.5)
    scale = det_cfg.get("scale_factor", 0.5)
    every_n = max(1, det_cfg.get("process_every_n_frames", 3))
    cooldown = det_cfg.get("cooldown_seconds", 60)
    log_unknown = det_cfg.get("log_unknown", True)
    show_window = disp_cfg.get("show_window", True)
    upsample = det_cfg.get("upsample", 1)
    model = det_cfg.get("model", "hog")
    roi = det_cfg.get("roi")  # [x1,y1,x2,y2] as 0..1 fractions of the frame, or null

    known_encodings, known_names = load_known_faces(path_cfg["known_faces_dir"])

    if not known_encodings and not log_unknown:
        print("[ERROR] No known faces found, and log_unknown is false — nothing to detect.")
        print("        Run: python register_face.py   (or set detection.log_unknown = true)")
        return

    print(f"[INFO] Connecting to '{camera_name}' ({cam_cfg['source']})...")
    stream = CameraStream(
        source=cam_cfg["source"],
        reconnect_delay=cam_cfg.get("reconnect_delay_seconds", 5),
        name=camera_name,
    ).start()

    wait_start = time.time()
    while stream.read() is None:
        if time.time() - wait_start > 20:
            print("[ERROR] No frame received within 20s.")
            print("        Check the RTSP URL, camera credentials, and network connectivity.")
            stream.stop()
            return
        time.sleep(0.2)

    print("[INFO] Stream connected. Detection is running.")
    if show_window:
        print("[INFO] Press 'Q' in the video window to quit | 'R' to reload known faces\n")
    else:
        print("[INFO] Running headless (no preview window). Use stop.bat to stop.\n")

    last_seen: dict[str, float] = {}   # name -> last time we LOGGED them
    last_boxes: list = []              # boxes drawn on skipped frames
    frame_count = 0

    try:
        while True:
            frame = stream.read()
            if frame is None:
                time.sleep(0.03)
                continue

            frame_count += 1
            run_this_frame = (frame_count % every_n == 0)

            if run_this_frame:
                fh, fw = frame.shape[:2]
                if roi and len(roi) == 4:
                    rx1, ry1, rx2, ry2 = [int(v * fw) if i % 2 == 0 else int(v * fh)
                                           for i, v in enumerate(roi)]
                    roi_frame = frame[ry1:ry2, rx1:rx2]
                    offset_x, offset_y = rx1, ry1
                else:
                    roi_frame = frame
                    offset_x, offset_y = 0, 0

                small = cv2.resize(roi_frame, (0, 0), fx=scale, fy=scale)
                rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

                face_locations = face_recognition.face_locations(
                    rgb_small, number_of_times_to_upsample=upsample, model=model
                )
                face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

                last_boxes = []
                now_ts = time.time()

                for enc, loc in zip(face_encodings, face_locations):
                    name = "Unknown"
                    color = (0, 0, 220)  # red

                    if known_encodings:
                        distances = face_recognition.face_distance(known_encodings, enc)
                        best_idx = int(np.argmin(distances))
                        best_score = distances[best_idx]

                        if best_score <= tolerance:
                            name = known_names[best_idx]
                            color = (0, 200, 0)  # green

                    should_log = (name != "Unknown") or log_unknown
                    if should_log:
                        last_logged = last_seen.get(name, 0)
                        if now_ts - last_logged >= cooldown:
                            status = "Recognized" if name != "Unknown" else "Unknown"
                            log_detection(name, camera_name, status)
                            last_seen[name] = now_ts

                    scale_back = int(round(1 / scale))
                    top, right, bottom, left = [v * scale_back for v in loc]
                    top, bottom = top + offset_y, bottom + offset_y
                    left, right = left + offset_x, right + offset_x
                    last_boxes.append((name, color, (top, right, bottom, left)))

            # Draw the latest known boxes every frame, even skipped ones,
            # so the preview still looks smooth instead of stuttering.
            if show_window:
                for name, color, (top, right, bottom, left) in last_boxes:
                    cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                    cv2.rectangle(frame, (left, bottom - 34), (right, bottom), color, cv2.FILLED)
                    cv2.putText(frame, name, (left + 6, bottom - 8),
                                cv2.FONT_HERSHEY_DUPLEX, 0.7, (255, 255, 255), 1)

                status_color = (0, 220, 255) if stream.is_connected() else (0, 0, 220)
                cv2.putText(frame, time.strftime("%Y-%m-%d  %H:%M:%S"), (10, 28),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
                cv2.putText(frame, f"Camera: {camera_name}", (10, 56),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, status_color, 1)
                cv2.putText(frame, "Q=Quit  R=Reload faces", (10, frame.shape[0] - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180, 180, 180), 1)

                cv2.imshow("AI Face Detection - " + camera_name, frame)

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('r'):
                    known_encodings, known_names = load_known_faces(path_cfg["known_faces_dir"])
                    print(f"[INFO] Reloaded {len(known_names)} known face(s).")
            else:
                # Headless mode: nothing to draw, just keep the loop light.
                time.sleep(0.01)

    except KeyboardInterrupt:
        print("\n[INFO] Stopped by user (Ctrl+C).")
    finally:
        stream.stop()
        if show_window:
            cv2.destroyAllWindows()
        print("[INFO] Detection session ended.")


if __name__ == "__main__":
    run_detection()
