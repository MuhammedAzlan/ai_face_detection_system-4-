"""
utils/camera_stream.py
=======================
Threaded reader for a local webcam, RTSP IP camera, or NVR channel.

Two problems this solves that the original webcam-only code didn't have to:

1. RTSP streams buffer internally. If you just call cam.read() in your main
   loop, face detection (which is slow) falls behind and you end up watching
   video from several seconds ago. Reading in a background thread and always
   grabbing the newest frame avoids that lag.

2. IP cameras/NVRs drop connections (network blips, camera reboot, etc).
   This class detects a dead stream and automatically reconnects instead of
   crashing the whole program.
"""

import os
import cv2
import threading
import time

# Force RTSP over TCP by default. Most NVRs (Dahua/Hikvision included) are
# more reliable over TCP than UDP through routers/switches/VPNs. This must
# be set before the first cv2.VideoCapture(...) call for an rtsp:// source.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")

# If we get this many CONSECUTIVE failed connection attempts, stop retrying
# every `reconnect_delay` seconds and back off hard instead. This matters
# specifically for auth failures (401 Unauthorized): hammering a wrong
# password at an NVR every few seconds can trip its account-lockout
# protection (common on Dahua/Hikvision), making things worse, not better.
BACKOFF_AFTER_FAILURES = 3
BACKOFF_SECONDS = 60


class CameraStream:
    def __init__(self, source, reconnect_delay: float = 5, name: str = "Camera"):
        # source can be an RTSP/HTTP URL (str) or a webcam index (int, e.g. 0)
        self.source = source
        self.reconnect_delay = reconnect_delay
        self.name = name

        self.cap = None
        self.frame = None
        self.lock = threading.Lock()
        self.running = False
        self.connected = False
        self.thread = None
        self.consecutive_failures = 0

    def _connect(self) -> bool:
        if self.cap is not None:
            self.cap.release()
        self.cap = cv2.VideoCapture(self.source)
        try:
            # Keep the OS/driver buffer as small as possible so we always
            # get a recent frame rather than a queued-up old one.
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        self.connected = self.cap.isOpened()
        if self.connected:
            print(f"[INFO] {self.name}: connected.")
            self.consecutive_failures = 0
        else:
            self.consecutive_failures += 1
        return self.connected

    def start(self):
        self.running = True
        self._connect()
        self.thread = threading.Thread(target=self._update, daemon=True)
        self.thread.start()
        return self

    def _update(self):
        while self.running:
            if not self.connected:
                if self.consecutive_failures >= BACKOFF_AFTER_FAILURES:
                    print(f"[WARN] {self.name}: {self.consecutive_failures} failed connection "
                          f"attempts in a row. Backing off for {BACKOFF_SECONDS}s.")
                    print(f"[WARN] {self.name}: if this is a 401/Unauthorized error, STOP and check "
                          f"the RTSP URL/credentials in config.json (test them in VLC first) before "
                          f"retrying more - repeated failed logins can lock the camera account.")
                    time.sleep(BACKOFF_SECONDS)
                else:
                    print(f"[WARN] {self.name}: not connected. Retrying in {self.reconnect_delay}s...")
                    time.sleep(self.reconnect_delay)
                self._connect()
                continue

            ret, frame = self.cap.read()
            if not ret or frame is None:
                print(f"[WARN] {self.name}: lost the stream. Reconnecting...")
                self.connected = False
                continue

            with self.lock:
                self.frame = frame

    def read(self):
        """Return the most recent frame (or None if nothing received yet)."""
        with self.lock:
            return None if self.frame is None else self.frame.copy()

    def is_connected(self) -> bool:
        return self.connected

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=2)
        if self.cap is not None:
            self.cap.release()
