@echo off
cd /d "%~dp0"
title AI Face Detection System

:menu
cls
echo ================================================
echo    AI Face Detection System
echo ================================================
if exist web.pid (
    echo    Web Dashboard: RUNNING  (http://localhost:5000)
) else (
    echo    Web Dashboard: STOPPED
)
if exist detector.pid (
    echo    CLI Detector:  RUNNING
) else (
    echo    CLI Detector:  STOPPED
)
echo ================================================
echo   1. Start Web Dashboard  (browser UI - recommended)
echo   2. Stop Web Dashboard
echo   3. Start CLI Detector    (console window only)
echo   4. Stop CLI Detector
echo   5. Register a new face
echo   6. View today's detections (console)
echo   7. Install / update dependencies
echo   8. Edit camera settings (config.json)
echo   9. Exit
echo ================================================
set /p choice=Select an option (1-9): 

if "%choice%"=="1" (call start_web.bat) & goto menu
if "%choice%"=="2" (call stop_web.bat) & goto menu
if "%choice%"=="3" (call start.bat) & goto menu
if "%choice%"=="4" (call stop.bat) & goto menu
if "%choice%"=="5" (call register_face.bat) & goto menu
if "%choice%"=="6" (call view_report.bat) & goto menu
if "%choice%"=="7" (call install.bat) & goto menu
if "%choice%"=="8" (notepad config.json) & goto menu
if "%choice%"=="9" exit /b 0

goto menu
